/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Data;

import Entity.BaseEntitiy;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DosyaIslemleri {

    public void Ekle(BaseEntitiy be, String Txt) {
        try {
            String filePath = System.getProperty("user.dir") + "/src/Data/"+ Txt;
            FileWriter fileWriter = new FileWriter(filePath , true);
            try ( BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                bufferedWriter.append(be.toString() + "\n");
            }
        } catch (IOException e) {
        }
    }

    public void Sil( String Id,String Txt) throws IOException {
        System.out.println("dosya");
        try {
            List<String> yeniDosya;
            String filePath = System.getProperty("user.dir") + "/src/Data/"+ Txt;
            try ( FileReader fR = new FileReader(filePath)) {
                try ( BufferedReader bR = new BufferedReader(fR)) {
                    String line = bR.readLine();
                    yeniDosya = new ArrayList<>();
                    while (line != null) {
                        System.out.println("dongu");
                        String[] parts = line.split(";");
                        if (parts[0].equals(Id)) {
                            System.out.println("if");
                            line = bR.readLine();
                        } else {
                            yeniDosya.add(line);
                            line = bR.readLine();
                        }
                    }
                    bR.close();
                }
                fR.close();
            }
            String filePath2 = System.getProperty("user.dir") + "/src/Data/"+ Txt;
            try ( BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
                for (String satir : yeniDosya) {
                    writer.write(satir + "\n");
                }
                writer.close();
            }
        } catch (IOException e) {
        }
    }

}
