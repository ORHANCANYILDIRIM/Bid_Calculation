package Action;

import Controller.KaydolEkraniController;
import GUI.GirisEkrani;
import GUI.KaydolEkrani;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class KaydolEkraniAction implements ActionListener {

    KaydolEkrani kaydolEkrani;
    GirisEkrani girisEkrani;

    public KaydolEkraniAction(KaydolEkrani kaydolEkrani) {
        this.kaydolEkrani = kaydolEkrani;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == kaydolEkrani.getKaydolButonu()) {
            String kullaniciAdi = kaydolEkrani.getKullaniciAdiTextField().getText();
            String sifre = kaydolEkrani.getSifreTextField().getText();
            String telefonNoString = kaydolEkrani.getTelefonnoTextField().getText();

            KaydolEkraniController kaydolEkraniController = new KaydolEkraniController();
            try {
                kaydolEkraniController.Olustur(kullaniciAdi, sifre, telefonNoString);
            } catch (IOException ex) {
                Logger.getLogger(KaydolEkraniAction.class.getName()).log(Level.SEVERE, null, ex);
            }
            kaydolEkrani.dispose();
            girisEkrani = new GirisEkrani();
            JOptionPane.showMessageDialog(null, "Kayıt başarılı giriş yapınız.");
        }
        if (e.getSource() == kaydolEkrani.getGeriButon()) {
            girisEkrani = new GirisEkrani();
            kaydolEkrani.dispose();
        }
    }

}
