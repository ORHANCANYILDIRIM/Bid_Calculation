package Action;

import Controller.MusteriController;
import GUI.AnaEkran;
import GUI.MusteriOlusturmaEkrani;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class MusteriEkraniAction implements ActionListener{
    private MusteriOlusturmaEkrani MusteriEkrani;
    private MusteriController Mc;
    
    public MusteriEkraniAction(MusteriOlusturmaEkrani MusteriEkrani) {
        this.MusteriEkrani=MusteriEkrani;
    }   
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==MusteriEkrani.getMusteriEkle()){
            String AdSoyad=MusteriEkrani.getAdSoyadF().getText();
            String Email=MusteriEkrani.getEmailF().getText();
            String TelefoNo=MusteriEkrani.getTelefoNoF().getText();
            String SevkAdres=MusteriEkrani.getSevkAdresF().getText();

            if(AdSoyad.length()==0 || Email.length()==0 || TelefoNo.length()==0 || SevkAdres.length()==0){
                JOptionPane.showMessageDialog(null, "Eksik alanlari doldurunuz!");
            }
            else{
                try {
                    getMc().Olustur(AdSoyad, Email, TelefoNo, SevkAdres);
                    MusteriEkrani.getAdSoyadF().setText(null);
                    MusteriEkrani.getEmailF().setText(null);
                    MusteriEkrani.getTelefoNoF().setText(null);
                    MusteriEkrani.getSevkAdresF().setText(null);
                    MusteriEkrani.TabloGuncelle();

                } catch (IOException ex) {
                    Logger.getLogger(MusteriEkraniAction .class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            
        }
        if(e.getSource()==MusteriEkrani.getGeriDon()){
            new AnaEkran();
            MusteriEkrani.dispose();
        }

    }

    public MusteriController getMc() {
        if(Mc==null){
            Mc=new MusteriController();
        }
        return Mc;
    }

   
    
}
