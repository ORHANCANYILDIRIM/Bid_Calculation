package Action;

import Controller.HammaddeController;
import GUI.AnaEkran;
import GUI.HammaddeEklemeEkrani;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class HammaddeEkraniAction implements ActionListener{
    
    private HammaddeEklemeEkrani HammaddeEkrani;
    private HammaddeController Mc;
    
    public HammaddeEkraniAction(HammaddeEklemeEkrani HammaddeEkrani) {
        this.HammaddeEkrani = HammaddeEkrani;
    }
        
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == HammaddeEkrani.getHammaddeEkle()) {
            String AdSoyad = HammaddeEkrani.getMalzemeCinsiF().getText();
            String Email = HammaddeEkrani.getEbatKalinlikF().getText();
            String TelefoNo = HammaddeEkrani.getYogunlukF().getText();
            String SevkAdres = HammaddeEkrani.getKGfiyatiF().getText();

            if (AdSoyad.length() == 0 || Email.length() == 0 || TelefoNo.length() == 0 || SevkAdres.length() == 0) {
                JOptionPane.showMessageDialog(null, "Eksik alanlari doldurunuz!");
            } 
            else {
                try {
                    getMc().Olustur(AdSoyad, Email, TelefoNo, SevkAdres);
                    HammaddeEkrani.getMalzemeCinsiF().setText(null);
                    HammaddeEkrani.getEbatKalinlikF().setText(null);
                    HammaddeEkrani.getYogunlukF().setText(null);
                    HammaddeEkrani.getKGfiyatiF().setText(null);
                    HammaddeEkrani.TabloGuncelle();

                } catch (IOException ex) {
                    Logger.getLogger(HammaddeEkraniAction.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }        
        if(e.getSource() == HammaddeEkrani.getGeriDon()){
            new AnaEkran();
            HammaddeEkrani.dispose();
        }
        
    }
    
    public HammaddeController getMc() {
        if (Mc == null) {
            Mc = new HammaddeController();
        }
        return Mc;
    }
        
}
