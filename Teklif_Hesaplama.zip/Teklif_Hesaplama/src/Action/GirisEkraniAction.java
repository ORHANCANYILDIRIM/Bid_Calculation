package Action;

import Controller.GirisEkraniController;
import GUI.AnaEkran;
import GUI.GirisEkrani;
import GUI.KaydolEkrani;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class GirisEkraniAction implements ActionListener {

    GirisEkrani girisEkrani;
    AnaEkran anaEkran;
    KaydolEkrani kaydolEkrani;

    public GirisEkraniAction(GirisEkrani girisEkrani) {
        this.girisEkrani = girisEkrani;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == girisEkrani.getGirisButonu()) {
            String kullaniciAdi = girisEkrani.getTextField().getText();
            String sifre = girisEkrani.getPasswordField().getText();
            GirisEkraniController girisEkraniController = new GirisEkraniController();
            try {
                if (girisEkraniController.Kontrol(kullaniciAdi, sifre)) {
                    anaEkran = new AnaEkran();
                    girisEkrani.dispose();
                } else {
                    JOptionPane.showMessageDialog(null, "Giriş Bilgileri hatalıdır.");
                }
            } catch (IOException ex) {
                Logger.getLogger(GirisEkraniAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (e.getSource() == girisEkrani.getButton2()) {
            kaydolEkrani = new KaydolEkrani();
            girisEkrani.dispose();
        }
    }

}
