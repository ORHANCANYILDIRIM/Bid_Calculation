package Action;

import Controller.EnerjiController;
import GUI.AnaEkran;
import GUI.EnerjiHesaplamaEkrani;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class EnerjiHesaplamaAction implements ActionListener{
    
    private EnerjiHesaplamaEkrani EnerjiEkrani;
    private EnerjiController Mc;

    public EnerjiHesaplamaAction(EnerjiHesaplamaEkrani EnerjiEkrani) {
        this.EnerjiEkrani = EnerjiEkrani;
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
         if (e.getSource() == EnerjiEkrani.getEnerjiEkle()) {
            String Yıl = EnerjiEkrani.getYılF().getText();
            String Tutar = EnerjiEkrani.getTutarF().getText();


            if (Yıl.length() == 0 || Tutar.length() == 0) {
                JOptionPane.showMessageDialog(null, "Eksik alanlari doldurunuz!");
            } 
            else {
                try {
                    getMc().Olustur(Yıl, Tutar);
                    EnerjiEkrani.getYılF().setText(null);
                    EnerjiEkrani.getTutarF().setText(null);
                    EnerjiEkrani.TabloGuncelle();

                } catch (IOException ex) {
                    Logger.getLogger(EnerjiHesaplamaAction.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        } 
        if(e.getSource() == EnerjiEkrani.getGeriDon()){
            new AnaEkran();
            EnerjiEkrani.dispose();
        }
    }
    public EnerjiController getMc() {
        if (Mc == null) {
            Mc = new EnerjiController();
        }
        return Mc;
    }
}
