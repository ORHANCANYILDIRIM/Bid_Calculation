package Action;

import Controller.SiparisOlusturmaController;
import GUI.AnaEkran;
import GUI.SiparisOlusturmaEkrani;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SipariOlusturmaAction implements ActionListener{
    
    AnaEkran anaEkran;
    SiparisOlusturmaEkrani siparisOlusturmaEkrani;
    SiparisOlusturmaController siparisOlusturmaController;
    public SipariOlusturmaAction(SiparisOlusturmaEkrani siparisOlusturmaEkrani) {
        this.siparisOlusturmaEkrani = siparisOlusturmaEkrani;
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == siparisOlusturmaEkrani.getGeriDon()){
            anaEkran = new AnaEkran();
            siparisOlusturmaEkrani.dispose();
        }
        if(e.getSource() == siparisOlusturmaEkrani.getEkle()){
            String musteri = (String)siparisOlusturmaEkrani.getMusteriAdiF().getSelectedItem();
            String hammadde = (String)siparisOlusturmaEkrani.getHammaddeTercihF().getSelectedItem();
            String hammaddeadedi = siparisOlusturmaEkrani.gethammaddeAdetiF().getText();
            String parcaKodu = siparisOlusturmaEkrani.getParcaKoduF().getText();
            String siparisAdedi = siparisOlusturmaEkrani.getSiparisAdetF().getText();
            String calismaSuresi = siparisOlusturmaEkrani.getCalismaSuresiF().getText();
            String siparisGTarih = siparisOlusturmaEkrani.getSiparisTarihF().getText();          
            String teslimTarih = siparisOlusturmaEkrani.getTeslimTarihF().getText();
            siparisOlusturmaController = new SiparisOlusturmaController(this);
            try {           
                siparisOlusturmaController.Olustur(musteri,hammaddeadedi,hammadde,parcaKodu,siparisAdedi,calismaSuresi,siparisGTarih,teslimTarih);
                siparisOlusturmaEkrani.TabloGuncelle();
            } 
            catch (IOException ex) {
                Logger.getLogger(SipariOlusturmaAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
