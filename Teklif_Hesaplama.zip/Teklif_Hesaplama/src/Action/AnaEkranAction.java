package Action;

import GUI.AnaEkran;
import GUI.EnerjiHesaplamaEkrani;
import GUI.GirisEkrani;
import GUI.HammaddeEklemeEkrani;
import GUI.MusteriOlusturmaEkrani;
import GUI.SiparisOlusturmaEkrani;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AnaEkranAction implements ActionListener {

    GirisEkrani girisEkrani;
    AnaEkran anaEkran;
    EnerjiHesaplamaEkrani enerjiHesaplamaEkrani;
    MusteriOlusturmaEkrani musteriOlusturmaEkrani;
    HammaddeEklemeEkrani hammaddeEklemeEkrani;
    SiparisOlusturmaEkrani siparisOlusturmaEkrani;

    public AnaEkranAction(AnaEkran anaEkran) {
        this.anaEkran = anaEkran;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == anaEkran.getSiparisbuton()) {
            anaEkran.dispose();
            siparisOlusturmaEkrani = new SiparisOlusturmaEkrani();          
        }
        if (e.getSource() == anaEkran.getHammaddebuton()) {
            anaEkran.dispose();
            try {
                hammaddeEklemeEkrani = new HammaddeEklemeEkrani();
            } catch (IOException ex) {
                Logger.getLogger(AnaEkranAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (e.getSource() == anaEkran.getMusteributon()) {
            anaEkran.dispose();
            try {
                musteriOlusturmaEkrani = new MusteriOlusturmaEkrani();
            } catch (IOException ex) {
                Logger.getLogger(AnaEkranAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (e.getSource() == anaEkran.getEnerjibuton()) {
            anaEkran.dispose();
            try {
                enerjiHesaplamaEkrani = new EnerjiHesaplamaEkrani();
            } catch (IOException ex) {
                Logger.getLogger(AnaEkranAction.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
          if (e.getSource() == anaEkran.getGeriDon()) {
            anaEkran.dispose();
            girisEkrani = new GirisEkrani();
        }
    }

}
