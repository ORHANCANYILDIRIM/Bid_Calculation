package DAO;

import Entity.Musteri;
import Entity.Siparis;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SiparisDao extends AbstractDao{

    private List<Siparis> siparisList = new ArrayList<>();

    @Override
    public void Olustur(Object object) throws IOException {
        try {
            String filePath = System.getProperty("user.dir") + "/src/Data/Siparis.txt";
            FileWriter FR = new FileWriter(filePath, true);
            try ( BufferedWriter BR = new BufferedWriter(FR)) {
                BR.append(object + "\n");
            }
        } catch (IOException e) {

        }
    }

    @Override
    public AbstractDao Guncelle() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void Sil(int selectedRow) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void Al() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public List<Siparis> getList() throws IOException {
        String filePath = System.getProperty("user.dir") + "/src/Data/Siparis.txt";
        FileReader fileReader = new FileReader(filePath);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String line = bufferedReader.readLine();
        while (line != null) {
            String[] parts = line.split(";");
            Siparis musteri = new Siparis(parts[0], parts[1], parts[2], Integer.parseInt(parts[3]),Integer.parseInt(parts[4]),Integer.parseInt(parts[5]),parts[6],parts[7]);
            siparisList.add(musteri);
            line = bufferedReader.readLine();
        }
        bufferedReader.close(); //Dosya kapatılıyor
        return siparisList;
    }
}
