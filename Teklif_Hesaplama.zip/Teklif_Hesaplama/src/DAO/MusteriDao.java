package DAO;

import Entity.Musteri;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class MusteriDao extends AbstractDao {

    private List<Musteri> musterilist = new ArrayList<>();

    @Override
    public void Olustur(Object object) throws IOException {
        try {
            String filePath = System.getProperty("user.dir") + "/src/Data/Musteri.txt";
            FileWriter FR = new FileWriter(filePath, true);
            try ( BufferedWriter BR = new BufferedWriter(FR)) {
                BR.append(object + "\n");
            }
        } catch (IOException e) {

        }
    }

    public List<Musteri> getList() throws IOException {
        String filePath = System.getProperty("user.dir") + "/src/Data/Musteri.txt";
        FileReader fileReader = new FileReader(filePath);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String line = bufferedReader.readLine();
        while (line != null) {
            String[] parts = line.split(";");
            Musteri musteri = new Musteri(parts[0], parts[1], parts[2], parts[3]);
            musterilist.add(musteri);
            line = bufferedReader.readLine();
        }
        bufferedReader.close(); //Dosya kapatılıyor
        return musterilist;
    }

    public String[] FindMusteri(String M) throws FileNotFoundException, IOException {
        String filePath = System.getProperty("user.dir") + "/src/Data/Musteri.txt";
        FileReader fileReader = new FileReader(filePath);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String line = bufferedReader.readLine();
        String[] parts = line.split(";");
        while (line != null) {
            parts = line.split(";");
            if(parts[0].equals(M)){
                break;
            }
            line = bufferedReader.readLine();
        }
        bufferedReader.close(); //Dosya kapatılıyor
        return parts;
    }
    
    @Override
    public AbstractDao Guncelle() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void Sil(int selectedRow) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void Al() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
