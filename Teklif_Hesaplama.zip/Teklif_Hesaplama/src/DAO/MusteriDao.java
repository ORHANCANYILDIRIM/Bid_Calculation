/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Data.DosyaIslemleri;
import Entity.Musteri;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MusteriDao {

    DosyaIslemleri dosya = new DosyaIslemleri();
    private List<Musteri> musterilist = new ArrayList<>();

    public void insert(Musteri m) throws IOException {
        dosya.Ekle(m, "Musteri.txt");
    }

    public void sil(String ID) throws IOException {     
        System.out.println("dao");
        dosya.Sil(ID, "Musteri.txt");
    }
    public List<Musteri> getList() throws IOException {
    String filePath = System.getProperty("user.dir") + "/src/Data/Musteri.txt";
    FileReader fileReader = new FileReader(filePath);
    BufferedReader bufferedReader = new BufferedReader(fileReader);

    String line = bufferedReader.readLine();
    while (line != null) {
        String[] parts = line.split(";");
        Musteri musteri = new Musteri(parts[0], parts[1], parts[2], parts[3]);
        musterilist.add(musteri);
        line = bufferedReader.readLine();
    }
    bufferedReader.close(); //Dosya kapatılıyor
    return musterilist;
}



   
}

