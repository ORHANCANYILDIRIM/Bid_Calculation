/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAO;

import Entity.Hammadde;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class HammaddeDao extends AbstractDao{
        private List<Hammadde> hammaddelist = new ArrayList<>();

    @Override
    public void Olustur(Object object) throws IOException {
        try {
            String filePath = System.getProperty("user.dir") + "/src/Data/Hammadde.txt";
            FileWriter FR = new FileWriter(filePath, true);
            try ( BufferedWriter BR = new BufferedWriter(FR)) {
                BR.append(object + "\n");
            }
        } catch (IOException e) {

        }
    }

    public List<Hammadde> getList() throws IOException{
        String filePath = System.getProperty("user.dir") + "/src/Data/Hammadde.txt";
        FileReader fileReader = new FileReader(filePath);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String line = bufferedReader.readLine();
        while (line != null) {
            String[] parts = line.split(";");
            Hammadde hammadde = new Hammadde(parts[0], parts[1], parts[2], parts[3]);
            hammaddelist.add(hammadde);
            line = bufferedReader.readLine();
        }
        bufferedReader.close(); //Dosya kapatılıyor
        return hammaddelist;
    }

    @Override
    public AbstractDao Guncelle() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void Sil(int selectedRow) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void Al() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String[] FindHammadde(String hammadde) throws IOException {
        String filePath = System.getProperty("user.dir") + "/src/Data/Hammadde.txt";
        FileReader fileReader = new FileReader(filePath);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String line = bufferedReader.readLine();
        String[] parts = line.split(";");
        while (line != null) {
            parts = line.split(";");
            if(parts[1].equals(hammadde)){
                break;
            }
            line = bufferedReader.readLine();
        }
        bufferedReader.close(); //Dosya kapatılıyor
        return parts;
    }

}
