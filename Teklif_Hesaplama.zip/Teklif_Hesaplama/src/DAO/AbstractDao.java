package DAO;

import java.io.IOException;

public abstract class AbstractDao<T> {

    public abstract void Olustur(Object object) throws IOException;

    public abstract AbstractDao Guncelle();

    public abstract void Sil(int selectedRow);

    public abstract void Al();

}
