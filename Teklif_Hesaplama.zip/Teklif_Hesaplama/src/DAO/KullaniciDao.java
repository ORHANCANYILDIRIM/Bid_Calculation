package DAO;

import Entity.Kullanici;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class KullaniciDao extends AbstractDao {

    List<Kullanici> kullanicilar;

    public KullaniciDao() {
        kullanicilar = new ArrayList<>();
    }

    @Override
    public void Olustur(Object object) throws IOException {
        try {
            String filePath = System.getProperty("user.dir") + "/src/Data/Kullanici.txt";
            FileWriter FR = new FileWriter(filePath, true);
            try(BufferedWriter BR = new BufferedWriter(FR)){
               BR.append(object + "\n");
            }       
        } 
        catch (IOException e) {
            
        }
    }

    @Override
    public AbstractDao Guncelle() {
        return null;
    }

    @Override
    public void Al() {

    }

    public boolean Kontrol(Kullanici kullanici) throws FileNotFoundException, IOException {
        String filePath = System.getProperty("user.dir") + "/src/Data/Kullanici.txt";
        FileReader FR = new FileReader(filePath);
        BufferedReader BR = new BufferedReader(FR);
        String line;
        while ((line = BR.readLine()) != null) {
            String[] parts = line.split(";");
            String kullaniciAdi = parts[0];
            String sifre = parts[1];
            if (kullaniciAdi.equals(kullanici.getKullaniciAdi()) && sifre.equals(kullanici.getParola())) {
                BR.close();
                FR.close();
                return true;
            }
        }

        BR.close();
        FR.close();
        return false;

    }

    @Override
    public void Sil(int selectedRow) {
       
    }

}
