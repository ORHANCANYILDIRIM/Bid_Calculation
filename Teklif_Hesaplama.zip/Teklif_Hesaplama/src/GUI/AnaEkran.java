package GUI;


import Action.AnaEkranAction;
import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class AnaEkran extends JFrame{
   
    
    private JButton Musteributon;
    private JButton Hammaddebuton;
    private JButton Enerjibuton;
    private JButton Siparisbuton;
    private JButton GeriDon;
    
    public AnaEkran() {
       Olustur();    
    }

    private void Olustur(){
        add(PanelEkle());
        setTitle("Ana Ekran");
        setLocationRelativeTo(null);
        setBounds(300, 75, 1000, 650);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    private JPanel PanelEkle(){
        JPanel MüsteriPanel =new JPanel();
        MüsteriPanel.setBackground(new Color(255,240,255));
        MüsteriPanel.setLayout(null);
         
        MüsteriPanel.add(getMusteributon());
        MüsteriPanel.add(getHammaddebuton());
        MüsteriPanel.add(getEnerjibuton());
        MüsteriPanel.add(getSiparisbuton());
        MüsteriPanel.add(getGeriDon());
       
        
        
        
        return MüsteriPanel;
    }
    
    
    public JButton getSiparisbuton() {
        if(Siparisbuton==null){
            Siparisbuton=new JButton("Siparisbuton");
            Siparisbuton.addActionListener(new AnaEkranAction(this));
            Siparisbuton.setBounds(575, 350, 200, 150);
            Siparisbuton.setBackground(new Color(143,194,197));
        }
        return Siparisbuton;
    }

    public void setSiparisbuton(JButton Siparisbuton) {
        this.Siparisbuton = Siparisbuton;
    }
    
   
    public JButton getEnerjibuton() {
        if(Enerjibuton==null){
            Enerjibuton=new JButton("Enerjibuton");
            Enerjibuton.addActionListener(new AnaEkranAction(this));
            Enerjibuton.setBounds(175, 350, 200, 150);
            Enerjibuton.setBackground(new Color(143,194,197));
        }
        return Enerjibuton;
    }

    public void setEnerjibuton(JButton Enerjibuton) {
        this.Enerjibuton = Enerjibuton;
    }
    
    
    public JButton getHammaddebuton() {
        if(Hammaddebuton==null){
            Hammaddebuton=new JButton("Hammaddebuton");
            Hammaddebuton.addActionListener(new AnaEkranAction(this));
            Hammaddebuton.setBounds(575, 100, 200, 150);
            Hammaddebuton.setBackground(new Color(143,194,197));
        }
        return Hammaddebuton;
    }

    public void setHammaddebuton(JButton Hammaddebuton) {
        this.Hammaddebuton = Hammaddebuton;
    }
    
    
    public JButton getMusteributon() {
        if(Musteributon==null){
            Musteributon=new JButton("Musteributon");
            Musteributon.addActionListener(new AnaEkranAction(this));
            Musteributon.setBounds(175, 100, 200, 150);
            Musteributon.setBackground(new Color(143,194,197));
        }
        return Musteributon;
    }

    public void setMusteributon(JButton Musteributon) {
        this.Musteributon = Musteributon;
    }

    
    public JButton getGeriDon() {
        if(GeriDon==null){
            GeriDon=new JButton("Geri dön");
            GeriDon.addActionListener(new AnaEkranAction(this));
            GeriDon.setBounds(850, 550, 100, 30);
            GeriDon.setBackground(new Color(186,153,187));
        }
        return GeriDon;
    }

    public void setGeriDon(JButton GeriDon) {
        this.GeriDon = GeriDon;
    }
  
    
}

    

