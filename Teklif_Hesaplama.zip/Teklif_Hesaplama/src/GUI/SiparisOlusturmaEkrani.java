package GUI;

import Action.SipariOlusturmaAction;
import Controller.SiparisOlusturmaController;
import DAO.HammaddeDao;
import DAO.MusteriDao;
import DAO.SiparisDao;
import Entity.Hammadde;
import Entity.Musteri;
import Entity.Siparis;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class SiparisOlusturmaEkrani extends JFrame {

    private JTable SiparisTablo;
    private JPanel MüsteriPanel;
    private JLabel MusteriAdi;
    private JLabel hammaddeAdeti;
    private JLabel HammaddeTercih;
    private JLabel ParcaKodu;
    private JLabel SiparisAdet;
    private JLabel SiparisTarih;
    private JLabel TeslimTarih;
    private JLabel CalismaSuresi;
    private JTextField CalismaSuresiF;
    private JTextField SiparisTarihF;
    private JTextField TeslimTarihF;
    private JTextField SiparisAdetF;
    private JComboBox MusteriAdiF;
    private JComboBox HammaddeTercihF;
    private JTextField hammaddeAdetiF;
    private JTextField ParcaKoduF;
    private JScrollPane tabloPane;
    private JButton GeriDon;
    private JButton Ekle;
    private DefaultTableModel Siparismodel;
    public Object[] siparisveri;
    public MusteriDao musteridao;
    public HammaddeDao hammaddeDao;
    public SiparisDao siparisDao;
    private SiparisOlusturmaController siparisController;

    public SiparisOlusturmaEkrani(){
        musteridao = new MusteriDao();
        hammaddeDao = new HammaddeDao();
        Siparismodel = new DefaultTableModel();
        

        
        siparisveri = new Object[4];
        TabloOlustur();
        Olustur();
    }
    
    private void TabloOlustur() {
        SiparisDao siparisDao = new SiparisDao();
        siparisController = new SiparisOlusturmaController(this);
        Siparismodel = new DefaultTableModel();
        Object[] müsteriObje = new Object[4];

        müsteriObje[0] = "Müşteri Adı";
        müsteriObje[1] = "Sipariş Hammaddesi";
        müsteriObje[2] = "Sipariş Tarihi";
        müsteriObje[3] = "Teslim Tarihi";

        Siparismodel.setColumnIdentifiers(müsteriObje);
        siparisveri = new Object[4];

        List<Siparis> siparisler = siparisController.getList();
        for (int i = 0; i < siparisler.size(); i++) {
            siparisveri[0] = siparisler.get(i).getMusteri();
            siparisveri[1] = siparisler.get(i).getHammadde();
            siparisveri[2] = siparisler.get(i).getSipTarihi();
            siparisveri[3] = siparisler.get(i).getTeslimTarihi();
            Siparismodel.addRow(siparisveri);
        }

        PanelEkle();
    }

    public void TabloGuncelle() {
        List<Siparis> siparisler = siparisController.getList();
        Siparismodel.setRowCount(0);
        for (int i = 0; i < siparisler.size(); i++) {
            siparisveri[0] = siparisler.get(i).getMusteri();
            siparisveri[1] = siparisler.get(i).getHammadde();
            siparisveri[2] = siparisler.get(i).getSipTarihi();
            siparisveri[3] = siparisler.get(i).getTeslimTarihi();
            Siparismodel.addRow(siparisveri);
        }
        PanelEkle();
    }
    private void Olustur() {
        add(PanelEkle());
        setTitle("Sipariş Oluşturma");
        setLocationRelativeTo(null);
        setBounds(250, 75, 1000, 650);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private JPanel PanelEkle() {
        MüsteriPanel = getMüsteriPanel();
        MüsteriPanel.setBackground(new Color(255, 240, 255));
        MüsteriPanel.setLayout(null);

        MüsteriPanel.add(getTabloPane());
        MüsteriPanel.add(getMusteriAdi());
        MüsteriPanel.add(getMusteriAdiF());
        MüsteriPanel.add(getHammaddeAdeti());
        MüsteriPanel.add(gethammaddeAdetiF());
        MüsteriPanel.add(getHammaddeTercih());
        MüsteriPanel.add(getHammaddeTercihF());
        MüsteriPanel.add(getParcaKodu());
        MüsteriPanel.add(getParcaKoduF());
        MüsteriPanel.add(getSiparisAdet());
        MüsteriPanel.add(getSiparisAdetF());
        MüsteriPanel.add(getCalismaSuresi());
        MüsteriPanel.add(getCalismaSuresiF());
        MüsteriPanel.add(getTeslimTarih());
        MüsteriPanel.add(getTeslimTarihF());
        MüsteriPanel.add(getSiparisTarih());
        MüsteriPanel.add(getSiparisTarihF());
        MüsteriPanel.add(getGeriDon());
        MüsteriPanel.add(getEkle());

        return MüsteriPanel;
    }

    public JTable getMüsteriTablo() {
        if (SiparisTablo == null) {
            SiparisTablo = new JTable();
            SiparisTablo.setModel(Siparismodel);
        }
        return SiparisTablo;
    }

    public void setSiparisTablo(JTable SiparisTablo) {
        this.SiparisTablo = SiparisTablo;
    }

    public JScrollPane getTabloPane() {
        if (tabloPane == null) {
            tabloPane = new JScrollPane();
            tabloPane.setViewportView(getMüsteriTablo());
            tabloPane.setBounds(473, 46, 500, 480);
        }
        return tabloPane;
    }

    public void setTabloPane(JScrollPane tabloPane) {
        this.tabloPane = tabloPane;
    }

    public JLabel getMusteriAdi() {
        if (MusteriAdi == null) {
            MusteriAdi = new JLabel("Müşteri Adı :");
            MusteriAdi.setBounds(57, 56, 100, 25);
            MusteriAdi.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        }
        return MusteriAdi;
    }

    public void setMusteriAdi(JLabel MusteriAdi) {
        this.MusteriAdi = MusteriAdi;
    }

    public JComboBox getMusteriAdiF() {
        if (MusteriAdiF == null) {
            List<Musteri> musteriler;
            try {
                musteriler = musteridao.getList();
                String[] musteriListesi = new String[musteriler.size()];
                int i = 0;
                while (i < musteriler.size()) {
                    musteriListesi[i] = musteriler.get(i).getAdSoyad();
                    i++;
                }
                MusteriAdiF = new JComboBox(musteriListesi);
            } 
            catch (IOException ex) {
                
            }
            MusteriAdiF.setBounds(227, 56, 150, 25);
        }
        return MusteriAdiF;
    }

    public void setMusteriAdiF(JComboBox MusteriAdiF) {
        this.MusteriAdiF = MusteriAdiF;
    }

    public JLabel getHammaddeAdeti() {
        if (hammaddeAdeti == null) {
            hammaddeAdeti = new JLabel(" Hammadde adeti :");
            hammaddeAdeti.setBounds(50, 100, 150, 25);
            hammaddeAdeti.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        }
        return hammaddeAdeti;
    }

    public void setHammaddeAdeti(JLabel hammaddeAdeti) {
        this.hammaddeAdeti = hammaddeAdeti;
    }

    public JTextField gethammaddeAdetiF() {
        if (hammaddeAdetiF == null) {
            hammaddeAdetiF = new JTextField();
            hammaddeAdetiF.setBounds(227, 100, 150, 25);
        }
        return hammaddeAdetiF;
    }

    public void sethammaddeAdetiF(JTextField TeslimatAdresiF) {
        this.hammaddeAdetiF = hammaddeAdetiF;
    }

    public JLabel getHammaddeTercih() {
        if (HammaddeTercih == null) {
            HammaddeTercih = new JLabel("Hammadde Tercihi:");
            HammaddeTercih.setBounds(57, 144, 150, 25);
            HammaddeTercih.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        }
        return HammaddeTercih;
    }

    public void setHammaddeTercih(JLabel HammaddeTercih) {
        this.HammaddeTercih = HammaddeTercih;
    }

    public JComboBox getHammaddeTercihF() {
        if (HammaddeTercihF == null) {
            List<Hammadde> Hammaddeler;
            try {
                Hammaddeler = hammaddeDao.getList();
                String[] HammaddeListesi = new String[Hammaddeler.size()];
                int i = 0;
                while (i < Hammaddeler.size()) {
                    HammaddeListesi[i] = Hammaddeler.get(i).getMalzemeCinsi();
                    i++;
                }
                HammaddeTercihF = new JComboBox(HammaddeListesi);
            } 
            catch (IOException ex) {
                
            }
            HammaddeTercihF.setBounds(227, 144, 150, 25);
        }
        return HammaddeTercihF;
    }

    public void setHammaddeTercihF(JComboBox HammaddeTercihF) {
        this.HammaddeTercihF = HammaddeTercihF;
    }

    public JLabel getParcaKodu() {
        if (ParcaKodu == null) {
            ParcaKodu = new JLabel("Parça Kodu :");
            ParcaKodu.setBounds(57, 188, 120, 25);
            ParcaKodu.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        }
        return ParcaKodu;
    }

    public void setParcaKodu(JLabel ParcaKodu) {
        this.ParcaKodu = ParcaKodu;
    }

    public JTextField getParcaKoduF() {
        if (ParcaKoduF == null) {
            ParcaKoduF = new JTextField();
            ParcaKoduF.setBounds(227, 188, 150, 25);
        }
        return ParcaKoduF;
    }

    public void setParcaKoduF(JTextField ParcaKoduF) {
        this.ParcaKoduF = ParcaKoduF;
    }

    public JLabel getSiparisAdet() {
        if (SiparisAdet == null) {
            SiparisAdet = new JLabel("Sipariş Adedi :");
            SiparisAdet.setBounds(57, 286, 120, 25);
            SiparisAdet.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        }
        return SiparisAdet;
    }

    public void setSiparisAdet(JLabel SiparisAdet) {
        this.SiparisAdet = SiparisAdet;
    }

    public JTextField getSiparisAdetF() {
        if (SiparisAdetF == null) {
            SiparisAdetF = new JTextField();
            SiparisAdetF.setBounds(227, 286, 150, 25);
        }
        return SiparisAdetF;
    }

    public void setSiparisAdetF(JTextField SiparisAdetF) {
        this.SiparisAdetF = SiparisAdetF;
    }
    
     public JLabel getCalismaSuresi() {
        if (CalismaSuresi == null) {
            CalismaSuresi = new JLabel("ÇalışmaSüresi (dk):");
            CalismaSuresi.setBounds(57, 232, 220, 25);
            CalismaSuresi.setFont(new Font("Times New Roman", Font.PLAIN, 17));
        }
        return CalismaSuresi;
    }

    public void setCalismaSuresi(JLabel CalismaSuresi) {
        this.CalismaSuresi = CalismaSuresi;
    }

    public JTextField getCalismaSuresiF() {
        if (CalismaSuresiF == null) {
            CalismaSuresiF = new JTextField();
            CalismaSuresiF.setBounds(227, 232, 150, 25);
        }
        return CalismaSuresiF;
    }

    public void setCalismaSuresiF(JTextField CalismaSuresiF) {
        this.CalismaSuresiF = CalismaSuresiF;
    }

    public JLabel getSiparisTarih() {
        if (SiparisTarih == null) {
            SiparisTarih = new JLabel("Sipariş Geçme Tarihi:");
            SiparisTarih.setBounds(52, 362, 180, 25);
            SiparisTarih.setFont(new Font("Times New Roman", Font.PLAIN, 17));
        }
        return SiparisTarih;
    }

    public void setSiparisTarih(JLabel SiparisTarih) {
        this.SiparisTarih = SiparisTarih;
    }

    public JTextField getSiparisTarihF() {
        if (SiparisTarihF == null) {
            SiparisTarihF = new JTextField();
            SiparisTarihF.setBounds(64, 404, 120, 25);
        }
        return SiparisTarihF;
    }

    public void setSiparisTarihF(JTextField SiparisTarihF) {
        this.SiparisTarihF = SiparisTarihF;
    }

    public JLabel getTeslimTarih() {
        if (TeslimTarih == null) {
            TeslimTarih = new JLabel("Talep Edilen Teslim Tarihi:");
            TeslimTarih.setBounds(235, 362, 220, 25);
            TeslimTarih.setFont(new Font("Times New Roman", Font.PLAIN, 17));
        }
        return TeslimTarih;
    }

    public void setTeslimTarih(JLabel TeslimTarih) {
        this.TeslimTarih = TeslimTarih;
    }

    public JTextField getTeslimTarihF() {
        if (TeslimTarihF == null) {
            TeslimTarihF = new JTextField();
            TeslimTarihF.setBounds(250, 404, 130, 25);
        }
        return TeslimTarihF;
    }

    public void setTeslimTarihF(JTextField TeslimTarihF) {
        this.TeslimTarihF = TeslimTarihF;
    }

    public JButton getGeriDon() {
        if (GeriDon == null) {
            GeriDon = new JButton("Geri dön");
            GeriDon.setBounds(850, 550, 100, 30);
            GeriDon.setBackground(new Color(186, 153, 187));
            GeriDon.addActionListener(new SipariOlusturmaAction(this));
        }
        return GeriDon;
    }

    public void setGeriDon(JButton GeriDon) {
        this.GeriDon = GeriDon;
    }

    public JButton getEkle() {
        if (Ekle == null) {
            Ekle = new JButton("Sipariş Oluştur");
            Ekle.setBounds(110, 475, 200, 40);
            Ekle.setFont(new Font("Times New Roman", Font.PLAIN, 20));
            Ekle.setBackground(new Color(143, 194, 197));
            Ekle.addActionListener(new SipariOlusturmaAction(this));
        }
        return Ekle;
    }

    public void setEkle(JButton Ekle) {
        this.Ekle = Ekle;
    }

    public JPanel getMüsteriPanel() {
        if (MüsteriPanel == null) {
            MüsteriPanel = new JPanel();
            MüsteriPanel.setBounds(250, 300, 900, 600);
        }
        return MüsteriPanel;
    }

    public void setMüsteriPanel(JPanel MüsteriPanel) {
        this.MüsteriPanel = MüsteriPanel;
    }

    
}
