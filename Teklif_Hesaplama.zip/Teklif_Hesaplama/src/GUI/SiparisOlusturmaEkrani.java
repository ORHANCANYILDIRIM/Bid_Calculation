package GUI;


import DAO.MusteriDao;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.table.DefaultTableModel;

public class SiparisOlusturmaEkrani extends JFrame{
    private JTable SiparisTablo;
    private JLabel MusteriAdi;
    private JLabel TeslimatAdresi;
    private JLabel HammaddeTercih;
    private JLabel ParcaKodu;
    private JLabel GazTercih;
    private JLabel SiparisAdet;
    private JLabel SiparisTarih;
    private JLabel TeslimTarih;
    private JRadioButton Gaz1;
    private JRadioButton Gaz2;
    private JRadioButton Gaz3;
    private JTextField SiparisTarihF;
    private JTextField TeslimTarihF;
    private JComboBox SiparisAdetF;
    private JComboBox MusteriAdiF;
    private JComboBox HammaddeTercihF;
    private JTextPane TeslimatAdresiF;
    private JTextField ParcaKoduF;
    private JScrollPane tabloPane;
    private JButton GeriDon;
    private JButton Ekle;
    private DefaultTableModel Siparismodel;
    public Object[] siparisveri;   
    
   
    
    public SiparisOlusturmaEkrani() throws IOException {
       MusteriDao musteridao =new MusteriDao();
        
       Siparismodel = new DefaultTableModel();
       Object[] müsteriObje = new Object[4];
       
       müsteriObje[0] = "Müşteri Adı";
       müsteriObje[1] = "Sipariş Bilgisi";
       müsteriObje[2] = "Sipariş Tarihi";
       müsteriObje[3] = "Teslim Tarihi";

       Siparismodel.setColumnIdentifiers(müsteriObje);
       siparisveri = new Object[4];
       
      
       Olustur();    
    }
    
    
    

    private void Olustur(){
        add(PanelEkle());
        setTitle("Sipariş Oluşturma");
        setLocationRelativeTo(null);
        setBounds(300, 75, 1000, 650);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    private JPanel PanelEkle(){
        JPanel MüsteriPanel =new JPanel();
        MüsteriPanel.setBackground(new Color(255,240,255));
        MüsteriPanel.setLayout(null);

        MüsteriPanel.add(getTabloPane());
        MüsteriPanel.add(getMusteriAdi());
        MüsteriPanel.add(getMusteriAdiF());
        MüsteriPanel.add(getTeslimatAdresi());
        MüsteriPanel.add(getTeslimatAdresiF());
        MüsteriPanel.add(getHammaddeTercih());
        MüsteriPanel.add(getHammaddeTercihF());
        MüsteriPanel.add(getParcaKodu());
        MüsteriPanel.add(getParcaKoduF());
        MüsteriPanel.add(getGazTercih());
        MüsteriPanel.add(getGaz1());
        MüsteriPanel.add(getGaz2());
        MüsteriPanel.add(getGaz3());
        MüsteriPanel.add(getSiparisAdet());
        MüsteriPanel.add(getSiparisAdetF());
        MüsteriPanel.add(getTeslimTarih());
        MüsteriPanel.add(getTeslimTarihF());
        MüsteriPanel.add(getSiparisTarih());
        MüsteriPanel.add(getSiparisTarihF());
        MüsteriPanel.add(getGeriDon());
        MüsteriPanel.add(getEkle());
        
        return MüsteriPanel;
    }

    public JTable getMüsteriTablo() {
        if(SiparisTablo==null){
           SiparisTablo=new JTable();
           SiparisTablo.setModel(Siparismodel);
        }
        return SiparisTablo;
    }

    public void setSiparisTablo(JTable SiparisTablo) {
        this.SiparisTablo = SiparisTablo;
    }

        public JScrollPane getTabloPane() {
        if(tabloPane==null){
            tabloPane=new JScrollPane();
            tabloPane.setViewportView(getMüsteriTablo());
            tabloPane.setBounds(473, 46, 500, 480);
        }
        return tabloPane;
    }

    public void setTabloPane(JScrollPane tabloPane) {
        this.tabloPane = tabloPane;
    }

    public JLabel getMusteriAdi() {
        if(MusteriAdi==null){
            MusteriAdi=new JLabel("Müşteri Adı :");
            MusteriAdi.setBounds(57, 56, 100, 25);
            MusteriAdi.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        }
        return MusteriAdi;
    }

    public void setMusteriAdi(JLabel MusteriAdi) {
        this.MusteriAdi = MusteriAdi;
    }
    
         public JComboBox getMusteriAdiF() {
        if(MusteriAdiF==null){
           MusteriAdiF=new JComboBox();
           MusteriAdiF.setBounds(227, 56, 150, 25);
        }
        return MusteriAdiF;
    }

    public void setMusteriAdiF(JComboBox MusteriAdiF) {
        this.MusteriAdiF = MusteriAdiF;
    }

    public JLabel getTeslimatAdresi() {
        if(TeslimatAdresi==null){
            TeslimatAdresi=new JLabel(" Teslimat Adresi :");
            TeslimatAdresi.setBounds(50, 100, 136, 25);
            TeslimatAdresi.setFont(new Font("Times New Roman", Font.PLAIN, 18));           
        }
        return TeslimatAdresi;
    }

    public void setTeslimatAdresi(JLabel TeslimatAdresi) {
        this.TeslimatAdresi = TeslimatAdresi;
    }
    
     public JTextPane getTeslimatAdresiF() {
        if(TeslimatAdresiF==null){
           TeslimatAdresiF=new JTextPane();
           TeslimatAdresiF.setBounds(227, 100, 150, 25);
        }
        return TeslimatAdresiF;
    }

    public void setTeslimatAdresiF(JTextPane TeslimatAdresiF) {
        this.TeslimatAdresiF = TeslimatAdresiF;
    }
    

    public JLabel getHammaddeTercih() {
        if(HammaddeTercih==null){
            HammaddeTercih=new JLabel("Hammadde Tercihi:");
            HammaddeTercih.setBounds(57, 144, 150, 25);
            HammaddeTercih.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        }
        return HammaddeTercih;
    }

    public void setHammaddeTercih(JLabel HammaddeTercih) {
        this.HammaddeTercih = HammaddeTercih;
    }
    
    public JComboBox getHammaddeTercihF() {
        if(HammaddeTercihF==null){
           HammaddeTercihF=new JComboBox();
           HammaddeTercihF.setBounds(227, 144, 150, 25);
        }
        return HammaddeTercihF;
    }

    public void setHammaddeTercihF(JComboBox HammaddeTercihF) {
        this.HammaddeTercihF = HammaddeTercihF;
    }
    
         public JLabel getParcaKodu() {
        if(ParcaKodu==null){
           ParcaKodu=new JLabel("Parça Kodu :");
           ParcaKodu.setBounds(57, 188, 120, 25);
           ParcaKodu.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        } 
        return ParcaKodu;
    }

    public void setParcaKodu(JLabel ParcaKodu) {
        this.ParcaKodu = ParcaKodu;
    }
    
        public JTextField getParcaKoduF() {
        if(ParcaKoduF==null){
           ParcaKoduF=new JTextField();
           ParcaKoduF.setBounds(227, 188, 150, 25);
        } 
        return ParcaKoduF;
    }

    public void setParcaKoduF(JTextField ParcaKoduF) {
        this.ParcaKoduF = ParcaKoduF;
    }
    
         public JLabel getGazTercih() {
        if(GazTercih==null){
           GazTercih=new JLabel("Gaz Tercihi :");
           GazTercih.setBounds(57, 232, 100, 25);
           GazTercih.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        } 
        return GazTercih;
    }

    public void setGazTercih(JLabel GazTercih) {
        this.GazTercih = GazTercih;
    }
    
        public JRadioButton getGaz1() {
        if(Gaz1==null){
           Gaz1=new JRadioButton("Gaz1:");
           Gaz1.setBounds(197, 232, 60, 30);
           Gaz1.setBackground(new Color(255,240,255));
           Gaz1.setFont(new Font("Times New Roman", Font.PLAIN, 15));
        } 
        return Gaz1;
    }
    public void setGaz1(JRadioButton Gaz1) {
        this.Gaz1 = Gaz1;
    }
    public JRadioButton getGaz2() {
        if(Gaz2==null){
           Gaz2=new JRadioButton("Gaz2:");
           Gaz2.setBounds(262, 232, 60, 30);
           Gaz2.setBackground(new Color(255,240,255));
           Gaz2.setFont(new Font("Times New Roman", Font.PLAIN, 15));
        } 
        return Gaz2;
    }
    public void setGaz2(JRadioButton Gaz2) {
        this.Gaz2 = Gaz2;
    }
    public JRadioButton getGaz3() {
        if(Gaz3==null){
           Gaz3=new JRadioButton("Gaz3:");
           Gaz3.setBounds(330, 232, 60, 30);
           Gaz3.setBackground(new Color(255,240,255));
           Gaz3.setFont(new Font("Times New Roman", Font.PLAIN, 15));
        } 
        return Gaz3;
    }
    public void setGaz3(JRadioButton Gaz3) {
        this.Gaz3 = Gaz3;
    }
    
         public JLabel getSiparisAdet() {
        if(SiparisAdet==null){
           SiparisAdet=new JLabel("Sipariş Adedi :");
           SiparisAdet.setBounds(57, 276, 120, 25);
           SiparisAdet.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        } 
        return SiparisAdet;
    }

    public void setSiparisAdet(JLabel SiparisAdet) {
        this.SiparisAdet = SiparisAdet;
    }
    
    public JComboBox getSiparisAdetF() {
        if(SiparisAdetF==null){
           SiparisAdetF=new JComboBox();
           SiparisAdetF.setBounds(227, 276, 150, 25);
        }
        return SiparisAdetF;
    }

    public void setSiparisAdetF(JComboBox SiparisAdetF) {
        this.SiparisAdetF = SiparisAdetF;
    }
    
        public JLabel getSiparisTarih() {
        if(SiparisTarih==null){
           SiparisTarih=new JLabel("Sipariş Geçme Tarihi:");
           SiparisTarih.setBounds(52, 362, 180, 25);
           SiparisTarih.setFont(new Font("Times New Roman", Font.PLAIN, 17));
        } 
        return SiparisTarih;
    }

    public void setSiparisTarih(JLabel SiparisTarih) {
        this.SiparisTarih = SiparisTarih;
    }
    
     public JTextField getSiparisTarihF() {
        if(SiparisTarihF==null){
          SiparisTarihF=new JTextField();
           SiparisTarihF.setBounds(64, 404, 120, 25);
        } 
        return SiparisTarihF;
    }

    public void setSiparisTarihF(JTextField SiparisTarihF) {
        this.SiparisTarihF = SiparisTarihF;
    }
    
        public JLabel getTeslimTarih() {
        if(TeslimTarih==null){
           TeslimTarih=new JLabel("Talep Edilen Teslim Tarihi:");
           TeslimTarih.setBounds(235, 362, 220, 25);
           TeslimTarih.setFont(new Font("Times New Roman", Font.PLAIN, 17));
        } 
        return TeslimTarih;
    }

    public void setTeslimTarih(JLabel TeslimTarih) {
        this.TeslimTarih = TeslimTarih;
    }
    
     public JTextField getTeslimTarihF() {
        if(TeslimTarihF==null){
           TeslimTarihF=new JTextField();
           TeslimTarihF.setBounds(250, 404, 130, 25);
        } 
        return TeslimTarihF;
    }

    public void setTeslimTarihF(JTextField TeslimTarihF) {
        this.TeslimTarihF = TeslimTarihF;
    }
    

    public JButton getGeriDon() {
        if(GeriDon==null){
            GeriDon=new JButton("Geri dön");
            GeriDon.setBounds(850, 550, 100, 30);
            GeriDon.setBackground(new Color(186,153,187));
        }
        return GeriDon;
    }

    public void setGeriDon(JButton GeriDon) {
        this.GeriDon = GeriDon;
    } 

    
    public JButton getEkle() {
        if(Ekle==null){
           Ekle=new JButton("Sipariş Oluştur");
           Ekle.setBounds(110, 475, 200, 40);
           Ekle.setFont(new Font("Times New Roman", Font.PLAIN, 20));
           Ekle.setBackground(new Color(143,194,197));
        } 
        return Ekle;
    }

    public void setEkle(JButton Ekle) {
        this.Ekle = Ekle;
    }
  
    
}

    

