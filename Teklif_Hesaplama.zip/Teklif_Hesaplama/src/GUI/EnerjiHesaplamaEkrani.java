package GUI;

import Action.EnerjiHesaplamaAction;
import Controller.EnerjiController;
import DAO.EnerjiDao;
import Entity.Enerji;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class EnerjiHesaplamaEkrani extends JFrame {
    
    private JPanel enerjiEkraniPanel;
    private JTable EnerjiTablo;
    private JLabel Yıl;
    private JLabel Tutar;
    private JTextField YılF;
    private JTextField TutarF;
    private JScrollPane tabloPane;
    private JButton GeriDon;
    private JButton EnerjiEkle;
    private DefaultTableModel Enerjimodel;
    public Object[] enerjiVeri;
    public EnerjiController enerjiController;
    
    
    
    
    
    
    public EnerjiHesaplamaEkrani() throws IOException {
        TabloOlustur();
        Olustur();
    }
        
    private void TabloOlustur() throws IOException {    
        EnerjiDao enerjidao = new EnerjiDao();
        enerjiController = new EnerjiController();
        Enerjimodel = new DefaultTableModel();
        Object[] enerjiObje = new Object[2];

        enerjiObje[0] = "Yıl";
        enerjiObje[1] = "Enerji Masrafı";

        
        Enerjimodel.setColumnIdentifiers(enerjiObje);
        enerjiVeri = new Object[2];
        
         List<Enerji> enerjiler = enerjiController.ListeyiAl();
        for (int i = 0; i < enerjiler.size(); i++) {
            enerjiVeri[0] = enerjiler.get(i).getYıl();
            enerjiVeri[1] = enerjiler.get(i).getTutar();
            
            Enerjimodel.addRow(enerjiVeri);
        }

        PanelEkle();
    }
    
    public void TabloGuncelle() {
        List<Enerji> enerjiler = enerjiController.ListeyiAl();
        Enerjimodel.setRowCount(0);
        for (int i = 0; i < enerjiler.size(); i++) {
            enerjiVeri[0] = enerjiler.get(i).getYıl();
            enerjiVeri[1] = enerjiler.get(i).getTutar();
            Enerjimodel.addRow(enerjiVeri);
        }
        PanelEkle();
    }
    
    private void Olustur() {
        add(PanelEkle());
        setTitle("Enerji Hesaplama");
        setLocationRelativeTo(null);
        setBounds(250, 75, 1000, 650);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private JPanel PanelEkle() {
        JPanel MüsteriPanel = getEnerjiEkraniPanel();
        MüsteriPanel.setBackground(new Color(255, 240, 255));
        MüsteriPanel.setLayout(null);
        MüsteriPanel.add(getTabloPane());
        MüsteriPanel.add(getYıl());
        MüsteriPanel.add(getYılF());
        MüsteriPanel.add(getTutar());
        MüsteriPanel.add(getTutarF());
        MüsteriPanel.add(getGeriDon());
        MüsteriPanel.add(getEnerjiEkle());

        return MüsteriPanel;
    }

    public JTable getEnerjiTablo() {
        if (EnerjiTablo == null) {
            EnerjiTablo = new JTable();
            EnerjiTablo.setModel(Enerjimodel);
        }
        return EnerjiTablo;
    }

    public void setEnerjiTablo(JTable EnerjiTablo) {
        this.EnerjiTablo = EnerjiTablo;
    }

    public JLabel getYıl() {
        if (Yıl == null) {
            Yıl = new JLabel("Yıl :");
            Yıl.setBounds(50, 100, 200, 50);
            Yıl.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return Yıl;
    }

    public void setYıl(JLabel Yıl) {
        this.Yıl = Yıl;
    }

    public JLabel getTutar() {
        if (Tutar == null) {
            Tutar = new JLabel("Enerji Masrafı (dk) :");
            Tutar.setBounds(50, 230, 200, 50);
            Tutar.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return Tutar;
    }

    public void setTutar(JLabel Tutar) {
        this.Tutar = Tutar;
    }

    public JTextField getYılF() {
        if (YılF == null) {
            YılF = new JTextField();
            YılF.setBounds(50, 150, 200, 30);
        }
        return YılF;
    }

    public void setYılF(JTextField YılF) {
        this.YılF = YılF;
    }

    public JTextField getTutarF() {
        if (TutarF == null) {
            TutarF = new JTextField();
            TutarF.setBounds(50, 280, 200, 30);
        }
        return TutarF;
    }

    public void setTutarF(JTextField TutarF) {
        this.TutarF = TutarF;
    }

    public JScrollPane getTabloPane() {
        if (tabloPane == null) {
            tabloPane = new JScrollPane();
            tabloPane.setViewportView(getEnerjiTablo());
            tabloPane.setBounds(450, 50, 500, 450);
        }
        return tabloPane;
    }

    public void setTabloPane(JScrollPane tabloPane) {
        this.tabloPane = tabloPane;
    }

    public JButton getGeriDon() {
        if (GeriDon == null) {
            GeriDon = new JButton("Geri dön");
            GeriDon.setBounds(850, 550, 100, 30);
            GeriDon.setBackground(new Color(186, 153, 187));
            GeriDon.addActionListener(new EnerjiHesaplamaAction(this));
        }
        return GeriDon;
    }

    public void setGeriDon(JButton GeriDon) {
        this.GeriDon = GeriDon;
    }

    public JButton getEnerjiEkle() {
        if (EnerjiEkle == null) {
            EnerjiEkle = new JButton(" Enerji Ekle");
            EnerjiEkle.setBounds(120, 380, 200, 30);
            EnerjiEkle.setBackground(new Color(143, 194, 197));
            EnerjiEkle.addActionListener(new EnerjiHesaplamaAction(this));
        }
        return EnerjiEkle;
    }

    public void setEnerjiEkle(JButton EnerjiEkle) {
        this.EnerjiEkle = EnerjiEkle;
    }
    public JPanel getEnerjiEkraniPanel() {
        if (enerjiEkraniPanel == null) {
            enerjiEkraniPanel = new JPanel();
            enerjiEkraniPanel.setBounds(250, 300, 900, 600);
        }
        return enerjiEkraniPanel;
    }

    public void setEnerjiEkraniPanel(JPanel enerjiEkraniPanel) {
        this.enerjiEkraniPanel = enerjiEkraniPanel;
    }
}
