package GUI;

import Action.KaydolEkraniAction;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

public class KaydolEkrani extends JFrame {

    private JPanel panel;

    private JLabel kullaniciAdi;
    private JLabel sifre;
    private JLabel telefonno;

    private JTextField kullaniciAdiTextField;
    private JTextField sifreTextField;
    private JTextField telefonnoTextField;

    private JButton kaydolButonu;
    private JButton geriButon;

    public KaydolEkrani() {
        Olustur();
    }

    private void Olustur() {
        add(PanelEkle());
        setBounds(400, 115, 600, 600);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public JPanel PanelEkle() {
        panel = getPanel();
        panel.setBackground(new Color(255, 240, 255));
        panel.setLayout(null);
        panel.add(getSifre());
        panel.add(getSifreTextField());
        panel.add(getKullaniciAdi());
        panel.add(getKullaniciAdiTextField());
        panel.add(getTelefonno());
        panel.add(getTelefonnoTextField());
        panel.add(getKaydolButonu());
        panel.add(getGeriButon());

        return panel;
    }

    public JLabel getSifre() {
        if (sifre == null) {
            sifre = new JLabel("ŞİFRE :");
            sifre.setBounds(70, 150, 200, 50);
            sifre.setFont(new Font("Times New Roman", Font.PLAIN, 25));
        }
        return sifre;
    }

    public void setSifre(JLabel sifre) {
        this.sifre = sifre;
    }

    public JLabel getKullaniciAdi() {
        if (kullaniciAdi == null) {
            kullaniciAdi = new JLabel("KULLANICI ADI :");
            kullaniciAdi.setBounds(70, 50, 200, 50);
            kullaniciAdi.setFont(new Font("Times New Roman", Font.PLAIN, 25));
        }
        return kullaniciAdi;
    }

    public void setKullaniciAdi(JLabel kullaniciAdi) {
        this.kullaniciAdi = kullaniciAdi;
    }

    public JLabel getTelefonno() {
        if (telefonno == null) {
            telefonno = new JLabel("TELEFON NO :");
            telefonno.setBounds(70, 250, 200, 50);
            telefonno.setFont(new Font("Times New Roman", Font.PLAIN, 25));
        }
        return telefonno;
    }

    public void setTelefonno(JLabel telefonno) {
        this.telefonno = telefonno;
    }

    public JTextField getSifreTextField() {
        if (sifreTextField == null) {
            sifreTextField = new JTextField();
            sifreTextField.setBounds(300, 150, 200, 50);
        }
        return sifreTextField;
    }

    public void setSifreTextField(JTextField sifreTextField) {
        this.sifreTextField = sifreTextField;
    }

    public JTextField getKullaniciAdiTextField() {
        if (kullaniciAdiTextField == null) {
            kullaniciAdiTextField = new JTextField();
            kullaniciAdiTextField.setBounds(300, 50, 200, 50);
        }
        return kullaniciAdiTextField;
    }

    public void setKullaniciAdiTextField(JTextField kullaniciAdiTextField) {
        this.kullaniciAdiTextField = kullaniciAdiTextField;
    }

    public JTextField getTelefonnoTextField() {
        if (telefonnoTextField == null) {
            telefonnoTextField = new JTextField();
            telefonnoTextField.setBounds(300, 250, 200, 50);
        }
        return telefonnoTextField;
    }

    public void setTelefonnoTextField(JTextField telefonnoTextField) {
        this.telefonnoTextField = telefonnoTextField;
    }

    public JPanel getPanel() {
        if (panel == null) {
            panel = new JPanel();
        }
        return panel;
    }

    public void setPanel(JPanel panel) {
        this.panel = panel;
    }

    public JButton getKaydolButonu() {
        if (kaydolButonu == null) {
            kaydolButonu = new JButton("KAYDOL");
            kaydolButonu.setBounds(175, 390, 200, 50);
            kaydolButonu.addActionListener(new KaydolEkraniAction(this));
            kaydolButonu.setBackground(new Color(143, 194, 197));
        }
        return kaydolButonu;
    }

    public void setKaydolButonu(JButton kaydolButonu) {
        this.kaydolButonu = kaydolButonu;
    }

    public JButton getGeriButon() {
        if (geriButon == null) {
            geriButon = new JButton("GERİ");
            geriButon.setBounds(440, 490, 100, 40);
            geriButon.setBackground(new Color(186, 153, 187));
            geriButon.addActionListener(new KaydolEkraniAction(this));
        }
        return geriButon;
    }

    public void setGeriButon(JButton geriButon) {
        this.geriButon = geriButon;
    }

}
