package GUI;

import Action.HammaddeEkraniAction;
import Controller.HammaddeController;
import DAO.HammaddeDao;
import Entity.Hammadde;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class HammaddeEklemeEkrani extends JFrame {
    
    private JPanel hammaddeEkraniPanel;
    private JTable HammaddeTablo;
    private JLabel MalzemeCinsi;
    private JLabel EbatKalinlik;
    private JLabel Yogunluk;
    private JLabel KGfiyati;
    private JTextField MalzemeCinsiF;
    private JTextField YogunlukF;
    private JTextField EbatKalinlikF;
    private JTextField KGfiyatiF;
    private JScrollPane tabloPane;
    private JButton GeriDon;
    private JButton HammaddeEkle;
    private DefaultTableModel Hammaddemodel;
    public Object[] hammaddeVeri;
    public HammaddeController hammaddeController;
    
    public HammaddeEklemeEkrani() throws IOException {
        TabloOlustur();
        Olustur();
    }

    private void TabloOlustur() throws IOException {
        HammaddeDao hammaddedao = new HammaddeDao();
        hammaddeController = new HammaddeController();
        Hammaddemodel = new DefaultTableModel();
        Object[] hammaddeObje = new Object[4];

        hammaddeObje[0] = "MalzemeCinsi";
        hammaddeObje[1] = "EbatKalinlik";
        hammaddeObje[2] = "Yogunluk";
        hammaddeObje[3] = "KGfiyati";

        Hammaddemodel.setColumnIdentifiers(hammaddeObje);
        hammaddeVeri = new Object[4];

        List<Hammadde> hammaddeler = hammaddeController.ListeyiAl();
        for (int i = 0; i < hammaddeler.size(); i++) {
            hammaddeVeri[0] = hammaddeler.get(i).getMalzemeCinsi();
            hammaddeVeri[1] = hammaddeler.get(i).getEbatKalinlik();
            hammaddeVeri[2] = hammaddeler.get(i).getYogunluk();
            hammaddeVeri[3] = hammaddeler.get(i).getKGfiyati();
            Hammaddemodel.addRow(hammaddeVeri);
        }

        PanelEkle();
    }
       
    public void TabloGuncelle() {
        List<Hammadde> hammaddeler = hammaddeController.ListeyiAl();
        Hammaddemodel.setRowCount(0);
        for (int i = 0; i < hammaddeler.size(); i++) {
            hammaddeVeri[0] = hammaddeler.get(i).getMalzemeCinsi();
            hammaddeVeri[1] = hammaddeler.get(i).getEbatKalinlik();
            hammaddeVeri[2] = hammaddeler.get(i).getYogunluk();
            hammaddeVeri[3] = hammaddeler.get(i).getKGfiyati();
            Hammaddemodel.addRow(hammaddeVeri);
        }
        PanelEkle();
    }

    private void Olustur() {
        add(PanelEkle());
        setTitle("Hammadde Ekleme");
        setLocationRelativeTo(null);
        setBounds(250, 75, 1000, 650);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }

    private JPanel PanelEkle() {
        JPanel MüsteriPanel = getHammaddeEkraniPanel();
        MüsteriPanel.setBackground(new Color(255, 240, 255));
        MüsteriPanel.setLayout(null);

        MüsteriPanel.add(getTabloPane());
        MüsteriPanel.add(getMalzemeCinsi());
        MüsteriPanel.add(getMalzemeCinsiF());
        MüsteriPanel.add(getEbatKalinlik());
        MüsteriPanel.add(getEbatKalinlikF());
        MüsteriPanel.add(getYogunluk());
        MüsteriPanel.add(getYogunlukF());
        MüsteriPanel.add(getGeriDon());
        MüsteriPanel.add(getKGfiyati());
        MüsteriPanel.add(getKGfiyatiF());
        MüsteriPanel.add(getHammaddeEkle());

        return MüsteriPanel;
    }

    public JTable getHammaddeTablo() {
        if (HammaddeTablo == null) {
            HammaddeTablo = new JTable();
            HammaddeTablo.setModel(Hammaddemodel);
        }
        return HammaddeTablo;
    }

    public void setHammaddeTablo(JTable HammaddeTablo) {
        this.HammaddeTablo = HammaddeTablo;
    }

    public JLabel getMalzemeCinsi() {
        if (MalzemeCinsi == null) {
            MalzemeCinsi = new JLabel("Malzeme Cinsi :");
            MalzemeCinsi.setBounds(50, 100, 200, 50);
            MalzemeCinsi.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return MalzemeCinsi;
    }

    public void setMalzemeCinsi(JLabel MalzemeCinsi) {
        this.MalzemeCinsi = MalzemeCinsi;
    }

    public JLabel getEbatKalinlik() {
        if (EbatKalinlik == null) {
            EbatKalinlik = new JLabel("Hammadde Ebatları ve Kalınlığı :");
            EbatKalinlik.setBounds(50, 180, 280, 50);
            EbatKalinlik.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return EbatKalinlik;
    }

    public void setEbatKalinlik(JLabel EbatKalinlik) {
        this.EbatKalinlik = EbatKalinlik;
    }

    public JLabel getYogunluk() {
        if (Yogunluk == null) {
            Yogunluk = new JLabel("Hammadde Yoğunluğu :");
            Yogunluk.setBounds(50, 260, 200, 50);
            Yogunluk.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return Yogunluk;
    }

    public void setYogunluk(JLabel Yogunluk) {
        this.Yogunluk = Yogunluk;
    }

    public JTextField getMalzemeCinsiF() {
        if (MalzemeCinsiF == null) {
            MalzemeCinsiF = new JTextField();
            MalzemeCinsiF.setBounds(50, 150, 200, 30);
        }
        return MalzemeCinsiF;
    }

    public void setMalzemeCinsiF(JTextField MalzemeCinsiF) {
        this.MalzemeCinsiF = MalzemeCinsiF;
    }

    public JTextField getYogunlukF() {
        if (YogunlukF == null) {
            YogunlukF = new JTextField();
            YogunlukF.setBounds(50, 310, 200, 30);
        }
        return YogunlukF;
    }

    public void setYogunlukF(JTextField YogunlukF) {
        this.YogunlukF = YogunlukF;
    }

    public JTextField getEbatKalinlikF() {
        if (EbatKalinlikF == null) {
            EbatKalinlikF = new JTextField();
            EbatKalinlikF.setBounds(50, 230, 200, 30);
        }
        return EbatKalinlikF;
    }

    public void setEbatKalinlikF(JTextField EbatKalinlikF) {
        this.EbatKalinlikF = EbatKalinlikF;
    }

    public JScrollPane getTabloPane() {
        if (tabloPane == null) {
            tabloPane = new JScrollPane();
            tabloPane.setViewportView(getHammaddeTablo());
            tabloPane.setBounds(450, 50, 500, 450);
        }
        return tabloPane;
    }

    public void setTabloPane(JScrollPane tabloPane) {
        this.tabloPane = tabloPane;
    }

    public JButton getGeriDon() {
        if (GeriDon == null) {
            GeriDon = new JButton("Geri dön");
            GeriDon.setBounds(850, 550, 100, 30);
            GeriDon.setBackground(new Color(186, 153, 187));
            GeriDon.addActionListener(new HammaddeEkraniAction(this));
        }
        return GeriDon;
    }

    public void setGeriDon(JButton GeriDon) {
        this.GeriDon = GeriDon;
    }

    public JLabel getKGfiyati() {
        if (KGfiyati == null) {
            KGfiyati = new JLabel("Hammadde KG Fiyatı :");
            KGfiyati.setBounds(50, 360, 200, 30);
            KGfiyati.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return KGfiyati;
    }

    public void setKGfiyati(JLabel KGfiyati) {
        this.KGfiyati = KGfiyati;
    }

    public JTextField getKGfiyatiF() {
        if (KGfiyatiF == null) {
            KGfiyatiF = new JTextField();
            KGfiyatiF.setBounds(50, 410, 200, 30);
        }
        return KGfiyatiF;
    }

    public void setKGfiyatiF(JTextField KGfiyatiF) {
        this.KGfiyatiF = KGfiyatiF;
    }

    public JButton getHammaddeEkle() {
        if (HammaddeEkle == null) {
            HammaddeEkle = new JButton("Hammadde Ekle");
            HammaddeEkle.setBounds(50, 500, 200, 30);
            HammaddeEkle.setBackground(new Color(143, 194, 197));
            HammaddeEkle .addActionListener(new HammaddeEkraniAction(this));
        }
        return HammaddeEkle;
    }

    public void setHammaddeEkle(JButton HammaddeEkle) {
        this.HammaddeEkle = HammaddeEkle;
    }
    
    public JPanel getHammaddeEkraniPanel() {
        if (hammaddeEkraniPanel == null) {
            hammaddeEkraniPanel = new JPanel();
            hammaddeEkraniPanel.setBounds(250, 300, 900, 600);
        }
        return hammaddeEkraniPanel;
    }

    public void setHammaddeEkraniPanel(JPanel hammaddeEkraniPanel) {
        this.hammaddeEkraniPanel = hammaddeEkraniPanel;
    }

}
