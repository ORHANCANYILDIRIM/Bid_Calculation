package GUI;


import DAO.MusteriDao;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class HammaddeEklemeEkrani extends JFrame{
    private JTable HammaddeTablo;
    private JLabel MalzemeCinsi;
    private JLabel EbatKalinlik;
    private JLabel Yogunluk;
    private JLabel KGfiyati;
    private JTextField MalzemeCinsiF;
    private JTextField YogunlukF;
    private JTextField EbatKalinlikF;
    private JTextField KGfiyatiF;
    private JScrollPane tabloPane;
    private JButton GeriDon;
    private JButton Ekle;
    private DefaultTableModel Hammaddemodel;
    public Object[] HammaddeVeri;   
    
   
    
    public HammaddeEklemeEkrani() throws IOException {
       MusteriDao musteridao =new MusteriDao();
        
       Hammaddemodel = new DefaultTableModel();
       Object[] müsteriObje = new Object[4];
       
       müsteriObje[0] = "Malzeme Cinsi";
       müsteriObje[1] = "Ebat-Kalınlık";
       müsteriObje[2] = "Yoğunluk";
       müsteriObje[3] = "KG Fiyati";

       Hammaddemodel.setColumnIdentifiers(müsteriObje);
       HammaddeVeri = new Object[4];
       
      
       Olustur();    
    }
    
    
    

    private void Olustur(){
        add(PanelEkle());
        setTitle("Hammadde Ekleme");
        setLocationRelativeTo(null);
        setBounds(300, 75, 1000, 650);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    private JPanel PanelEkle(){
        JPanel MüsteriPanel =new JPanel();
        MüsteriPanel.setBackground(new Color(255,240,255));
        MüsteriPanel.setLayout(null);

        MüsteriPanel.add(getTabloPane());
        MüsteriPanel.add(getMalzemeCinsi());
        MüsteriPanel.add(getMalzemeCinsiF());
        MüsteriPanel.add(getEbatKalinlik());
        MüsteriPanel.add(getEbatKalinlikF());
        MüsteriPanel.add(getYogunluk());
        MüsteriPanel.add(getYogunlukF());
        MüsteriPanel.add(getGeriDon());
        MüsteriPanel.add(getKGfiyati());
        MüsteriPanel.add(getKGfiyatiF());
        MüsteriPanel.add(getEkle());
        
        return MüsteriPanel;
    }

    public JTable getHammaddeTablo() {
        if(HammaddeTablo==null){
           HammaddeTablo=new JTable();
           HammaddeTablo.setModel(Hammaddemodel);
        }
        return HammaddeTablo;
    }

    public void setHammaddeTablo(JTable HammaddeTablo) {
        this.HammaddeTablo = HammaddeTablo;
    }


    public JLabel getMalzemeCinsi() {
        if(MalzemeCinsi==null){
            MalzemeCinsi=new JLabel("Malzeme Cinsi :");
            MalzemeCinsi.setBounds(50, 100, 200, 50);
            MalzemeCinsi.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return MalzemeCinsi;
    }

    public void setMalzemeCinsi(JLabel MalzemeCinsi) {
        this.MalzemeCinsi = MalzemeCinsi;
    }

    public JLabel getEbatKalinlik() {
        if(EbatKalinlik==null){
            EbatKalinlik=new JLabel("Hammadde Ebatları ve Kalınlığı :");
            EbatKalinlik.setBounds(50, 180, 280, 50);
            EbatKalinlik.setFont(new Font("Times New Roman", Font.PLAIN, 20));           
        }
        return EbatKalinlik;
    }

    public void setEbatKalinlik(JLabel EbatKalinlik) {
        this.EbatKalinlik = EbatKalinlik;
    }

    public JLabel getYogunluk() {
        if(Yogunluk==null){
            Yogunluk=new JLabel("Hammadde Yoğunluğu :");
            Yogunluk.setBounds(50, 260, 200, 50);
            Yogunluk.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return Yogunluk;
    }

    public void setYogunluk(JLabel Yogunluk) {
        this.Yogunluk = Yogunluk;
    }

     public JTextField getMalzemeCinsiF() {
        if(MalzemeCinsiF==null){
          MalzemeCinsiF=new JTextField();
           MalzemeCinsiF.setBounds(50, 150, 200, 30);
        }
        return MalzemeCinsiF;
    }

    public void setMalzemeCinsiF(JTextField MalzemeCinsiF) {
        this.MalzemeCinsiF = MalzemeCinsiF;
    }

    public JTextField getYogunlukF() {
        if(YogunlukF==null){
           YogunlukF=new JTextField();
           YogunlukF.setBounds(50, 310, 200, 30);
        }
        return YogunlukF;
    }

    public void setYogunlukF(JTextField YogunlukF) {
        this.YogunlukF = YogunlukF;
    }

    public JTextField getEbatKalinlikF() {
        if(EbatKalinlikF==null){
           EbatKalinlikF=new JTextField();
           EbatKalinlikF.setBounds(50, 230, 200, 30);
        }
        return EbatKalinlikF;
    }

    public void setEbatKalinlikF(JTextField EbatKalinlikF) {
        this.EbatKalinlikF = EbatKalinlikF;
    }
    
    public JScrollPane getTabloPane() {
        if(tabloPane==null){
            tabloPane=new JScrollPane();
            tabloPane.setViewportView(getHammaddeTablo());
            tabloPane.setBounds(450, 50, 500, 450);
        }
        return tabloPane;
    }

    public void setTabloPane(JScrollPane tabloPane) {
        this.tabloPane = tabloPane;
    }
    

    
    public JButton getGeriDon() {
        if(GeriDon==null){
            GeriDon=new JButton("Geri dön");
            GeriDon.setBounds(850, 550, 100, 30);
            GeriDon.setBackground(new Color(186,153,187));
        }
        return GeriDon;
    }

    public void setGeriDon(JButton GeriDon) {
        this.GeriDon = GeriDon;
    }
    
     public JLabel getKGfiyati() {
        if(KGfiyati==null){
           KGfiyati=new JLabel("Hammadde KG Fiyatı :");
           KGfiyati.setBounds(50, 360, 200, 30);
           KGfiyati.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        } 
        return KGfiyati;
    }

    public void setKGfiyati(JLabel KGfiyati) {
        this.KGfiyati = KGfiyati;
    }

    public JTextField getKGfiyatiF() {
        if(KGfiyatiF==null){
           KGfiyatiF=new JTextField();
           KGfiyatiF.setBounds(50, 410, 200, 30);
        } 
        return KGfiyatiF;
    }

    public void setKGfiyatiF(JTextField KGfiyatiF) {
        this.KGfiyatiF = KGfiyatiF;
    }
       
    public JButton getEkle() {
        if(Ekle==null){
           Ekle=new JButton("Ekle");
           Ekle.setBounds(50, 500, 200, 30);
           Ekle.setBackground(new Color(143,194,197));
        } 
        return Ekle;
    }

    public void setEkle(JButton Ekle) {
        this.Ekle = Ekle;
    }
  
    
}

    

