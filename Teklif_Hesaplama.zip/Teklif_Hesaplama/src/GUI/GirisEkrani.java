package GUI;

import Action.GirisEkraniAction;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class GirisEkrani extends JFrame{
    private JLabel label1;
    private JLabel label2;
    private JTextField textField;
    private JPasswordField passwordField;
    private JButton girisButonu;
    private JButton button2;
    private JPanel panel1;

    public GirisEkrani() {
        Olustur();
    }
    
    private void Olustur(){
        add(PanelEkle());
        setBounds(700, 200, 600, 600);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
    
    public JPanel PanelEkle(){
        JPanel jpanel = getPanel1();
        jpanel.setBackground(new Color(255,240,255));
        jpanel.setLayout(null);
        jpanel.add(getLabel1());
        jpanel.add(getLabel2());
        jpanel.add(getTextField());
        jpanel.add(getPasswordField());
        jpanel.add(getGirisButonu());
        jpanel.add(getButton2());
        return jpanel;
    }

    public JLabel getLabel1() {
        if(label1 == null){
            label1 = new JLabel("KULLANICI ADI");
            label1.setBounds(50, 50, 400, 200);
            label1.setFont(new Font("Times New Roman",Font.PLAIN,20));
        }
        return label1;
    }

    public void setLabel1(JLabel label1) {
        this.label1 = label1;
    }

    public JLabel getLabel2() {
        if(label2 == null){
            label2 = new JLabel("ŞİFRE");
            label2.setBounds(50, 130, 400, 200);
            label2.setFont(new Font("Times New Roman",Font.PLAIN,20));
        }
        return label2;
    }

    public void setLabel2(JLabel label2) {
        this.label2 = label2;
    }

    public JTextField getTextField() {
        if(textField == null){
            textField = new JTextField();
            textField.setBounds(250, 130, 250, 50);
        }
        return textField;
    }

    public void setTextField(JTextField textField) {
        this.textField = textField;
    }

    public JPasswordField getPasswordField() {
        if(passwordField == null){
            passwordField = new JPasswordField();
            passwordField.setBounds(250, 200, 250, 50);
        }
        return passwordField;
    }

    public void setPasswordField(JPasswordField passwordField) {
        this.passwordField = passwordField;
    }

    public JButton getGirisButonu() {
        if(girisButonu == null){
            girisButonu = new JButton("Giriş yap");
            girisButonu.setBounds(250, 300, 100, 40);
            girisButonu.addActionListener(new GirisEkraniAction(this));
            girisButonu.setBackground(new Color(143,194,197));
        }
        return girisButonu;
    }

    public void setGirisButonu(JButton girisButonu) {
        this.girisButonu = girisButonu;
    }

    public JButton getButton2() {
        if(button2 == null){
            button2 = new JButton("Kaydol");
            button2.setBounds(400, 300, 100, 40);
            button2.addActionListener(new GirisEkraniAction(this));
            button2.setBackground(new Color(143,194,197));
        }
        return button2;
    }

    public void setButton2(JButton button2) {
        this.button2 = button2;
    }

    public JPanel getPanel1() {
        if(panel1 == null){
            panel1 = new JPanel();
        }
        return panel1;
    }

    public void setPanel1(JPanel panel1) {
        this.panel1 = panel1;
    }
    
    
    
    
    

}
