package GUI;



import Action.MusteriEkraniAction;
import Controller.MusteriController;
import DAO.MusteriDao;
import Entity.Musteri;
import java.awt.Color;
import java.awt.Font;
import java.io.IOException;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class MusteriOlusturmaEkrani extends JFrame{
    private JTable MusteriTablo;
    private JLabel AdSoyad;
    private JLabel TelefoNo;
    private JLabel Email;
    private JLabel SevkAdres;
    private JTextField AdSoyadF;
    private JTextField EmailF;
    private JTextField TelefoNoF;
    private JTextField SevkAdresF;
    private JScrollPane tabloPane;
    private JButton GeriDon;
    private JButton MusteriEkle;
    private DefaultTableModel Musterimodel;
    public Object[] musteriVeri;   
    public MusteriController  musteriController;
   
    
    public MusteriOlusturmaEkrani() throws IOException {
       TabloOlustur();
       
       
      
       Olustur();    
    }
    private void TabloOlustur(){
       MusteriDao musteridao =new MusteriDao();
       musteriController = new MusteriController();
       Musterimodel = new DefaultTableModel();
       Object[] müsteriObje = new Object[4];
       
       müsteriObje[0] = "Ad Soyad";
       müsteriObje[1] = "Tel No";
       müsteriObje[2] = "E-mail";
       müsteriObje[3] = "Adres";

       Musterimodel.setColumnIdentifiers(müsteriObje);
       musteriVeri = new Object[4];

        List<Musteri> musteriler = musteriController.ListeyiAl();
        for (int i = 0; i < musteriler.size(); i++) {
            musteriVeri[0] = musteriler.get(i).getAdSoyad();
            musteriVeri[1] = musteriler.get(i).getEmail();
            musteriVeri[2] = musteriler.get(i).gettelefoNo();
            musteriVeri[3] = musteriler.get(i).getSevkAdresi();
            Musterimodel.addRow(musteriVeri);
        }

        PanelEkle();
    }

public void TabloGuncelle() {
    Thread thread = new Thread(new Runnable() {
        @Override
        public void run() {
            List<Musteri> musteriler = musteriController.ListeyiAl();
            Musterimodel.setRowCount(0); // Tablodaki tüm satırları sil
            for (int i = 0; i < musteriler.size(); i++) {
                Object[] musteriVeri = new Object[4]; // Yeni dizi oluştur
                musteriVeri[0] = musteriler.get(i).getAdSoyad();
                musteriVeri[1] = musteriler.get(i).getEmail();
                musteriVeri[2] = musteriler.get(i).gettelefoNo();
                musteriVeri[3] = musteriler.get(i).getSevkAdresi();
                Musterimodel.addRow(musteriVeri);
            }
            
        }
    });
    thread.start();
}




    
    

    private void Olustur(){
        add(PanelEkle());
        setTitle("Müşteri Oluşturma");
        setLocationRelativeTo(null);
        setBounds(300, 75, 1000, 650);
        setVisible(true);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setResizable(false);
    }
    
    private JPanel PanelEkle(){
        JPanel MüsteriPanel =new JPanel();
        MüsteriPanel.setBackground(new Color(255,240,255));
        MüsteriPanel.setLayout(null);

        MüsteriPanel.add(getTabloPane());
        MüsteriPanel.add(getAdSoyad());
        MüsteriPanel.add(getAdSoyadF());
        MüsteriPanel.add(getTelefoNo());
        MüsteriPanel.add(getTelefoNoF());
        MüsteriPanel.add(getEmail());
        MüsteriPanel.add(getEmailF());
        MüsteriPanel.add(getGeriDon());
        MüsteriPanel.add(getSevkAdres());
        MüsteriPanel.add(getSevkAdresF());
        MüsteriPanel.add(getMusteriEkle());
        
        return MüsteriPanel;
    }

    public JTable getMusteriTablo() {
        if(MusteriTablo==null){
           MusteriTablo=new JTable();
           MusteriTablo.setModel(Musterimodel);
        }
        return MusteriTablo;
    }

    public void setMusteriTablo(JTable MusteriTablo) {
        this.MusteriTablo = MusteriTablo;
    }


    public JLabel getAdSoyad() {
        if(AdSoyad==null){
            AdSoyad=new JLabel("Ad Soyad :");
            AdSoyad.setBounds(50, 100, 200, 50);
            AdSoyad.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return AdSoyad;
    }

    public void setAdSoyad(JLabel AdSoyad) {
        this.AdSoyad = AdSoyad;
    }

    public JLabel getTelefoNo() {
        if(TelefoNo==null){
            TelefoNo=new JLabel("Telefon :");
            TelefoNo.setBounds(50, 260, 200, 50);
            TelefoNo.setFont(new Font("Times New Roman", Font.PLAIN, 20));           
        }
        return TelefoNo;
    }

    public void setTelefoNo(JLabel TelefoNo) {
        this.TelefoNo = TelefoNo;
    }

    public JLabel getEmail() {
        if(Email==null){
            Email=new JLabel("E-mail :");
            Email.setBounds(50, 180, 200, 50);
            Email.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        }
        return Email;
    }

    public void setEmail(JLabel Email) {
        this.Email = Email;
    }

     public JTextField getAdSoyadF() {
        if(AdSoyadF==null){
           AdSoyadF=new JTextField();
           AdSoyadF.setBounds(50, 150, 200, 30);
        }
        return AdSoyadF;
    }

    public void setAdSoyadF(JTextField AdSoyadF) {
        this.AdSoyadF = AdSoyadF;
    }

    public JTextField getEmailF() {
        if(EmailF==null){
           EmailF=new JTextField();
           EmailF.setBounds(50, 310, 200, 30);
        }
        return EmailF;
    }

    public void setEmailF(JTextField EmailF) {
        this.EmailF = EmailF;
    }

    public JTextField getTelefoNoF() {
        if(TelefoNoF==null){
           TelefoNoF=new JTextField();
           TelefoNoF.setBounds(50, 230, 200, 30);
        }
        return TelefoNoF;
    }

    public void setTelefoNoF(JTextField TelefoNoF) {
        this.TelefoNoF = TelefoNoF;
    }
    
    public JScrollPane getTabloPane() {
        if(tabloPane==null){
            tabloPane=new JScrollPane();
            tabloPane.setViewportView(getMusteriTablo());
            tabloPane.setBounds(450, 50, 500, 450);
        }
        return tabloPane;
    }

    public void setTabloPane(JScrollPane tabloPane) {
        this.tabloPane = tabloPane;
    }
    

    
    public JButton getGeriDon() {
        if(GeriDon==null){
            GeriDon=new JButton("Geri dön");
            GeriDon.setBounds(850, 550, 100, 30);
            GeriDon.setBackground(new Color(186,153,187));
            GeriDon.addActionListener(new MusteriEkraniAction(this));

        }
        return GeriDon;
    }

    public void setGeriDon(JButton GeriDon) {
        this.GeriDon = GeriDon;
    }
    
     public JLabel getSevkAdres() {
        if(SevkAdres==null){
           SevkAdres=new JLabel("Sevk Adresi :");
           SevkAdres.setBounds(50, 360, 100, 30);
           SevkAdres.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        } 
        return SevkAdres;
    }

    public void setSevkAdres(JLabel SevkAdres) {
        this.SevkAdres = SevkAdres;
    }

    public JTextField getSevkAdresF() {
        if(SevkAdresF==null){
           SevkAdresF=new JTextField();
           SevkAdresF.setBounds(50, 410, 200, 30);
        } 
        return SevkAdresF;
    }

    public void setSevkAdresF(JTextField SevkAdresF) {
        this.SevkAdresF = SevkAdresF;
    }
       
    public JButton getMusteriEkle() {
        if(MusteriEkle==null){
           MusteriEkle=new JButton("Müşteri Oluştur");
           MusteriEkle.setBounds(50, 500, 200, 30);
           MusteriEkle.setBackground(new Color(143,194,197));
           MusteriEkle.addActionListener(new MusteriEkraniAction(this));

        } 
        return MusteriEkle;
    }

    public void setMusteriEkle(JButton MusteriEkle) {
        this.MusteriEkle = MusteriEkle;
    }
  
    
}

    

