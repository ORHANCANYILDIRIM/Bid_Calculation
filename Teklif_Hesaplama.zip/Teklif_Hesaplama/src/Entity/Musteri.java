/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import java.util.Objects;

public class Musteri implements BaseEntitiy {

    private String AdSoyad;
    private String Email;
    private String telefoNo;
    private String SevkAdresi;

    public Musteri() {
    }

    public Musteri(String AdSoyad, String Email, String telefoNo, String SevkAdresi) {
        this.Email = Email;
        this.AdSoyad = AdSoyad;
        this.telefoNo = telefoNo;
        this.SevkAdresi = SevkAdresi;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.AdSoyad);
        hash = 97 * hash + Objects.hashCode(this.telefoNo);
        hash = 97 * hash + Objects.hashCode(this.Email);
        hash = 97 * hash + Objects.hashCode(this.SevkAdresi);

        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Musteri other = (Musteri) obj;
        return true;
    }

    @Override
    public String toString() {
        return AdSoyad + ";" + Email + ";" + telefoNo + ";" + SevkAdresi;                // değiştirdim

    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getAdSoyad() {
        return AdSoyad;
    }

    public void setAdSoyad(String AdSoyad) {
        this.AdSoyad = AdSoyad;
    }

    public String gettelefoNo() {
        return telefoNo;
    }

    public void settelefoNo(String telefoNo) {
        this.telefoNo = telefoNo;
    }

    public String getSevkAdresi() {
        return SevkAdresi;
    }

    public void setSevkAdresi(String SevkAdresi) {
        this.SevkAdresi = SevkAdresi;
    }

}
