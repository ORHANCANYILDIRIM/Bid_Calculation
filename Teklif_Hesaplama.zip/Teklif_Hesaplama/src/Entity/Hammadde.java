/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import java.util.Objects;

public class Hammadde implements BaseEntitiy{
    
    private String MalzemeCinsi;
    private String EbatKalinlik;
    private String Yogunluk;
    private String KGfiyati;

    public Hammadde() {
    }

    public Hammadde(String EbatKalinlik, String MalzemeCinsi, String Yogunluk, String KGfiyati) {
        this.MalzemeCinsi = MalzemeCinsi;
        this.EbatKalinlik = EbatKalinlik;
        this.Yogunluk = Yogunluk;
        this.KGfiyati = KGfiyati;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.EbatKalinlik);
        hash = 97 * hash + Objects.hashCode(this.Yogunluk);
        hash = 97 * hash + Objects.hashCode(this.MalzemeCinsi);
        hash = 97 * hash + Objects.hashCode(this.KGfiyati);

        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Hammadde other = (Hammadde) obj;
        return true;
    }

    @Override
    public String toString() {
        return EbatKalinlik + ";" + MalzemeCinsi + ";" + Yogunluk + ";" + KGfiyati;                // değiştirdim

    }

    public String getMalzemeCinsi() {
        return MalzemeCinsi;
    }

    public void setMalzemeCinsi(String MalzemeCinsi) {
        this.MalzemeCinsi = MalzemeCinsi;
    }

    public String getEbatKalinlik() {
        return EbatKalinlik;
    }

    public void setEbatKalinlik(String EbatKalinlik) {
        this.EbatKalinlik = EbatKalinlik;
    }

    public String getYogunluk() {
        return Yogunluk;
    }

    public void setYogunluk(String Yogunluk) {
        this.Yogunluk = Yogunluk;
    }

    public String getKGfiyati() {
        return KGfiyati;
    }

    public void setKGfiyati(String KGfiyati) {
        this.KGfiyati = KGfiyati;
    }

    
}
