/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Entity;

import java.util.Objects;



public class Enerji implements BaseEntitiy{
    
    private String Yıl;
    private String Tutar;

    public Enerji() {
    }
    
    public Enerji(String Yıl, String Tutar) {
        this.Yıl = Yıl;
        this.Tutar = Tutar;
    }
    
    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + Objects.hashCode(this.Yıl);
        hash = 97 * hash + Objects.hashCode(this.Tutar);

        return hash;
    }
     @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Enerji other = (Enerji) obj;
        return true;
    }
    
    @Override
    public String toString() {
        return Yıl + ";" + Tutar;                // değiştirdim

    }
    
        public String getYıl() {
        return Yıl;
    }

    public void setYıl(String Yıl) {
        this.Yıl = Yıl;
    }
    
    public String getTutar() {
        return Tutar;
    }

    public void setTutar(String Tutar) {
        this.Tutar = Tutar;
    }
    
}
