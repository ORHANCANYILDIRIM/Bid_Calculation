package Entity;

public class Siparis implements BaseEntitiy{
    private String musteri;
    private String hammadde;
    private String parcaKodu;
    private int hammaddeAdeti;
    private int calismaSuresi;
    private int siparisAdedi;
    private String sipTarihi;
    private String teslimTarihi;

    public Siparis(String musteri, String hammadde, String parcaKodu, int hammaddeAdeti, int calismaSuresi, int siparisAdedi, String sipTarihi, String teslimTarihi) {
        this.musteri = musteri;
        this.hammadde = hammadde;
        this.parcaKodu = parcaKodu;
        this.hammaddeAdeti = hammaddeAdeti;
        this.calismaSuresi = calismaSuresi;
        this.siparisAdedi = siparisAdedi;
        this.sipTarihi = sipTarihi;
        this.teslimTarihi = teslimTarihi;
    }

    public String getMusteri() {
        return musteri;
    }

    public void setMusteri(String musteri) {
        this.musteri = musteri;
    }

    public String getHammadde() {
        return hammadde;
    }

    public void setHammadde(String hammadde) {
        this.hammadde = hammadde;
    }

    public String getParcaKodu() {
        return parcaKodu;
    }

    public void setParcaKodu(String parcaKodu) {
        this.parcaKodu = parcaKodu;
    }

    public int getHammaddeAdeti() {
        return hammaddeAdeti;
    }

    public void setHammaddeAdeti(int hammaddeAdeti) {
        this.hammaddeAdeti = hammaddeAdeti;
    }

    public int getCalismaSuresi() {
        return calismaSuresi;
    }

    public void setCalismaSuresi(int calismaSuresi) {
        this.calismaSuresi = calismaSuresi;
    }

    public int getSiparisAdedi() {
        return siparisAdedi;
    }

    public void setSiparisAdedi(int siparisAdedi) {
        this.siparisAdedi = siparisAdedi;
    }

    public String getSipTarihi() {
        return sipTarihi;
    }

    public void setSipTarihi(String sipTarihi) {
        this.sipTarihi = sipTarihi;
    }

    public String getTeslimTarihi() {
        return teslimTarihi;
    }

    public void setTeslimTarihi(String teslimTarihi) {
        this.teslimTarihi = teslimTarihi;
    }
    
    @Override
    public String toString() {
        return musteri + ";" +hammadde + ";" +parcaKodu + ";" +hammaddeAdeti + ";" +calismaSuresi + ";" +siparisAdedi + ";" +sipTarihi + ";" +teslimTarihi;                // değiştirdim

    }
}
