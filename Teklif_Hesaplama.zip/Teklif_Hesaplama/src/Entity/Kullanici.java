package Entity;

public class Kullanici {

    private String kullaniciAdi;
    private String parola;
    private String telNo;

    public Kullanici(String kullaniciAdi, String parola, String telNo) {
        this.kullaniciAdi = kullaniciAdi;
        this.parola = parola;
        this.telNo = telNo;
    }

    public Kullanici(String kullaniciAdi, String parola) {
        this.kullaniciAdi = kullaniciAdi;
        this.parola = parola;
    }

    public String getKullaniciAdi() {
        return kullaniciAdi;
    }

    public void setKullaniciAdi(String kullaniciAdi) {
        this.kullaniciAdi = kullaniciAdi;
    }

    public String getParola() {
        return parola;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }

    public String getTelNo() {
        return telNo;
    }

    public void setTelNo(String telNo) {
        this.telNo = telNo;
    }

    @Override
    public String toString() {
        return kullaniciAdi + ";" + parola + ";" + telNo;
    }
}
