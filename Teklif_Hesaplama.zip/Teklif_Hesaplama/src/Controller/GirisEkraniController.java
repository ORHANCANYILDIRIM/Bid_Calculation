package Controller;

import DAO.KullaniciDao;
import Entity.Kullanici;
import java.io.IOException;

public class GirisEkraniController {

    public boolean Kontrol(String kullaniciAdi, String parola) throws IOException {
        Kullanici kullanici = new Kullanici(kullaniciAdi, parola);
        KullaniciDao kullanıcılarDao = new KullaniciDao();
        return kullanıcılarDao.Kontrol(kullanici);
    }

}
