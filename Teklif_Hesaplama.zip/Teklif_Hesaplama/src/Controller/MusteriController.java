/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import DAO.MusteriDao;
import Entity.Musteri;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MusteriController {
    private Musteri musteri;           // Entity açılacak
    private List<Musteri> list;
    private MusteriDao dao;           // DAO açılacak

    public MusteriController() {
    }
    
    public void Olustur( String AdSoyad, String Email,String telefoNo,String SevkAdresi) throws IOException{
        Musteri newmusteri = this.getMusteri();
        newmusteri.setAdSoyad(AdSoyad);
        newmusteri.setEmail(Email);
        newmusteri.settelefoNo(telefoNo);
        newmusteri.setSevkAdresi(SevkAdresi);
       
        this.getDao().insert(newmusteri);   
    }
    
     public void sil(String Id) throws IOException{
        System.out.println("controller");                                       //// anlamadım neresi burası 
        this.getDao().sil(Id);   
    }

    public Musteri getMusteri() {
        if(musteri==null){
            musteri=new Musteri();
        }
        return musteri;
    }

    public void setMusteri(Musteri musteri) {
        this.musteri = musteri;
    }

    public List<Musteri> getList() {
        return list;
    }

    public void setList(List<Musteri> list) {
        this.list = list;
    }

    public MusteriDao getDao() {
        if(dao==null){
            dao=new MusteriDao();
        }
        return dao;
    }

    public void setDao(MusteriDao dao) {
        this.dao = dao;
    }

    public List<Musteri> ListeyiAl() {
        List<Musteri> Musteriler; 
        try {
            Musteriler = getDao().getList();
            return Musteriler;
        } catch (IOException ex) {
            Logger.getLogger(MusteriController.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        
    }
    
    
}
