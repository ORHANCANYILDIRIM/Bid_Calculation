/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import DAO.EnerjiDao;
import Entity.Enerji;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class EnerjiController {
    private Enerji enerji;
    private List<Enerji> list;
    private EnerjiDao dao;
    
    public EnerjiController(){
    }
    
    public void Olustur(String Yıl, String Tutar) throws IOException {
        Enerji newenerji = this.getEnerji();
        newenerji.setYıl(Yıl);
        newenerji.setTutar(Tutar);

        this.getDao().Olustur(newenerji);
    }
        public void sil(String Id) throws IOException {
        System.out.println("controller");                                       //// anlamadım neresi burası 
        //this.getDao().sil(Id);
    }
        
    public Enerji getEnerji() {
        if (enerji == null) {
            enerji = new Enerji();
        }
        return enerji;
    }

    public void setEnerji(Enerji enerji) {
        this.enerji = enerji;
    }    
    
    public List<Enerji> getList() {
        return list;
    }

    public void setList(List<Enerji> list) {
        this.list = list;
    }
    
    public EnerjiDao getDao() {
        if (dao == null) {
            dao = new EnerjiDao();
        }
        return dao;
    }

    public void setDao(EnerjiDao dao) {
        this.dao = dao;
    }
    
       public List<Enerji> ListeyiAl() {
        EnerjiDao enerjiDao = new EnerjiDao();
        List<Enerji> filmlerrr; 
        try {
            filmlerrr = enerjiDao.getList();
            return filmlerrr;
        } catch (IOException ex) {
            Logger.getLogger(EnerjiController.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        

    }
}
