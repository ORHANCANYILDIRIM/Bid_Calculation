package Controller;

import Action.SipariOlusturmaAction;
import DAO.EnerjiDao;
import DAO.HammaddeDao;
import DAO.MusteriDao;
import DAO.SiparisDao;
import Entity.Musteri;
import Entity.Siparis;
import GUI.SiparisOlusturmaEkrani;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SiparisOlusturmaController {

    SipariOlusturmaAction siparisOlusturmaAction;
    MusteriDao musteriDao;
    HammaddeDao hammaddeDao;
    SiparisDao siparisDao;
    EnerjiDao enerjiDao;
    List<Siparis> siparisler;
    private SiparisOlusturmaEkrani siparisOlusturmaEkrani;
    
    public SiparisOlusturmaController(SiparisOlusturmaEkrani siparisOlusturmaEkrani) {
        this.siparisOlusturmaEkrani = siparisOlusturmaEkrani;
        musteriDao = new MusteriDao();
        hammaddeDao = new HammaddeDao();
        siparisDao = new SiparisDao();
        enerjiDao = new EnerjiDao();
    }
    
    public SiparisOlusturmaController(SipariOlusturmaAction siparisOlusturmaAction) {
        this.siparisOlusturmaAction = siparisOlusturmaAction;
        musteriDao = new MusteriDao();
        hammaddeDao = new HammaddeDao();
        siparisDao = new SiparisDao();
        enerjiDao = new EnerjiDao();
    }

    public void Olustur(String musteri, String hammaddeadedi, String hammadde, String parcaKodu, String siparisAdedi, String calismaSuresi, String siparisGTarih, String teslimTarih) throws IOException {
        String musteriBilgileri[] = musteriDao.FindMusteri(musteri);
        String hammaddeBilgileri[] = hammaddeDao.FindHammadde(hammadde);

        float ebat = Float.parseFloat(hammaddeBilgileri[0]);
        float yogunluk = Float.parseFloat(hammaddeBilgileri[2]);
        float kgFiyati = Float.parseFloat(hammaddeBilgileri[3]);
        int hammaddeadediI = Integer.parseInt(hammaddeadedi);
        int siparisAdediII = Integer.parseInt(siparisAdedi);
        int enerjiFiyat = enerjiDao.FindFiyat(siparisGTarih);
        int calismaSuresiI = Integer.parseInt(calismaSuresi);
        Siparis siparis = new Siparis(musteri, hammadde, parcaKodu, hammaddeadediI, calismaSuresiI, siparisAdediII, siparisGTarih, teslimTarih);
        siparisDao.Olustur(siparis);
        float maliyet = MaliyetHesapla(ebat, yogunluk, kgFiyati, hammaddeadediI, siparisAdediII, enerjiFiyat, calismaSuresiI);
        Yazdir(musteriBilgileri, hammaddeBilgileri, hammaddeadedi, siparisAdedi, siparisGTarih, teslimTarih,siparis,maliyet);
    }

    private float MaliyetHesapla(float ebat, float yogunluk, float kgFiyati, int hammaddeadedi, int siparisAdedi, int enerjiFiyat, int calismaSuresi) {

        float HamKilo = hammaddeadedi * ebat * yogunluk;
        float HamMaliyet = HamKilo * kgFiyati;
        int EnerjiMaliyet = calismaSuresi * enerjiFiyat;
        float ToplamMaliyet = HamMaliyet * EnerjiMaliyet * siparisAdedi;

        return ToplamMaliyet;
    }

    private void Yazdir(String[] musteriBilgileri, String[] hammaddeBilgileri, String hammaddeadedi, String siparisAdedi, String siparisGTarih, String teslimTarih,Siparis siparis,float maliyet) {
        String dosyaAdi = System.getProperty("user.dir") + "/src/Siparisler/"+musteriBilgileri[0]+siparisGTarih+".txt";
        File dosya = new File(dosyaAdi);
        try {
            // Dosyayı açar ve verileri yazdırır.
            BufferedWriter yazici = new BufferedWriter(new FileWriter(dosya));
            yazici.write("Müşteri Bilgileri:\n");           
            yazici.write("\nAd Soyad: " + musteriBilgileri[0] + "\n");
            yazici.write("\nTel No: " + musteriBilgileri[1] + "\n");   
            yazici.write("\nE Mail: " + musteriBilgileri[2] + "\n");   
            yazici.write("\nAdres: " + musteriBilgileri[3] + "\n");   
            yazici.write("\nHammadde Bilgileri: \n");
            yazici.write("\nMalzeme Cinsi: " + hammaddeBilgileri[1] + "\n"); 
            yazici.write("\nEbat: " + hammaddeBilgileri[0] + "\n"); 
            yazici.write("\nYoğunluk : " + hammaddeBilgileri[2] + "\n"); 
            yazici.write("\nKg fiyatı: " + hammaddeBilgileri[3] + "\n"); 
            yazici.write("\nHammadde Adedi: " + hammaddeadedi + "\n");
            yazici.write("\nSipariş Adedi: " + siparisAdedi + "\n");
            yazici.write("\nToplam Maliyet: " + maliyet + "TL \n");
            yazici.write("\nSipariş Tarihi: " + siparisGTarih + "\n");
            yazici.write("\nTeslim Tarihi: " + teslimTarih + "\n");
            yazici.close();
            System.out.println("Dosya başarıyla oluşturuldu: " + dosyaAdi);
        } 
        catch (IOException e) {
            System.out.println("Dosya oluşturma hatası: " + e.getMessage());
        }
    }

    public List<Siparis> getList() {
        SiparisDao Dao = new SiparisDao();
        List<Siparis> musteriler; 
        try {
            siparisler = Dao.getList();
            return siparisler;
        } 
        catch (IOException ex) {
            Logger.getLogger(MusteriController.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

}
