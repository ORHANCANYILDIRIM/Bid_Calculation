/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import DAO.HammaddeDao;
import Entity.Hammadde;
import java.io.IOException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class HammaddeController {
    private Hammadde hammadde;           // Entity açılacak
    private List<Hammadde> list;
    private HammaddeDao dao;           // DAO açılacak

    public HammaddeController() {
    }

    public void Olustur(String MalzemeCinsi, String EbatKalinlik, String Yogunluk, String KGfiyati) throws IOException {
        Hammadde newhammadde = this.getHammadde();
        newhammadde.setMalzemeCinsi(MalzemeCinsi);
        newhammadde.setEbatKalinlik(EbatKalinlik);
        newhammadde.setYogunluk(Yogunluk);
        newhammadde.setKGfiyati(KGfiyati);

        this.getDao().Olustur(newhammadde);
    }

    public void sil(String Id) throws IOException {
        System.out.println("controller");                                       //// anlamadım neresi burası 
        //this.getDao().sil(Id);
    }

    public Hammadde getHammadde() {
        if (hammadde == null) {
            hammadde = new Hammadde();
        }
        return hammadde;
    }

    public void setHammadde(Hammadde hammadde) {
        this.hammadde = hammadde;
    }

    public List<Hammadde> getList() {
        return list;
    }

    public void setList(List<Hammadde> list) {
        this.list = list;
    }

    public HammaddeDao getDao() {
        if (dao == null) {
            dao = new HammaddeDao();
        }
        return dao;
    }

    public void setDao(HammaddeDao dao) {
        this.dao = dao;
    }

    public List<Hammadde> ListeyiAl() {
        HammaddeDao hammaddeDao = new HammaddeDao();
        List<Hammadde> filmlerr; 
        try {
            filmlerr = hammaddeDao.getList();
            return filmlerr;
        } catch (IOException ex) {
            Logger.getLogger(HammaddeController.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
        

    }

}
