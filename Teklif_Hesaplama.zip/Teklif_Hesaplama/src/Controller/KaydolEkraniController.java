package Controller;

import DAO.KullaniciDao;
import Entity.Kullanici;
import java.io.IOException;

public class KaydolEkraniController {
        
    public void Olustur(String kullaniciAdi,String sifre,String telNo) throws IOException{
        Kullanici kullanici = new Kullanici(kullaniciAdi,sifre,telNo);
        KullaniciDao kullanıcılarDao = new KullaniciDao();
        kullanıcılarDao.Olustur(kullanici.toString());    
    }
}
