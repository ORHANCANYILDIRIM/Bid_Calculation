package Main;


import GUI.AnaEkran;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        Run();
    }

    private static void Run() throws IOException {
        AnaEkran anaEkran = new AnaEkran();
        //GirisEkrani girisEkrani = new GirisEkrani();
        //SiparisOlusturmaEkrani siparisOlusturmaEkrani = new SiparisOlusturmaEkrani();
    }
    
}
