package Main;

import GUI.GirisEkrani;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws IOException {
        Run();
    }

    private static void Run() throws IOException {
        GirisEkrani girisEkrani = new GirisEkrani();
    }

}
